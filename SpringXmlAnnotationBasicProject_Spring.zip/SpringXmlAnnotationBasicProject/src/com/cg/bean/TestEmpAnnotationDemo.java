package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmpAnnotationDemo {

	public static void main(String[] args) {

		ApplicationContext ctx=new ClassPathXmlApplicationContext("CgXmlAnnotation.xml");
		
		Employee e1=(Employee)ctx.getBean("emp1");
		System.out.println(e1);
		
		System.out.println("----------------------------------------------");
		Emp e2=(Emp)ctx.getBean("emp2");
		System.out.println(e2);
		
		System.out.println("----------------------------------------------");
		Employee e3=(Employee)ctx.getBean("offemp2");
		System.out.println(e3);
	}

}
