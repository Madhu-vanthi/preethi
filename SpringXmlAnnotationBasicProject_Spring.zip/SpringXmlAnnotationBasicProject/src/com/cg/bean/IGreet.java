package com.cg.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;

public interface IGreet {
	
	public String greetMe();


}
