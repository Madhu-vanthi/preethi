package com.cg.selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class WorkingWithForms {

	public static void main(String[] args) {		
		
		String driverPath = "D:\\Lesson 5-HTML Pages\\chromedriver_win32\\";
		
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		WebDriver driver = new ChromeDriver();
		
		driver.get("file:///D:/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		
		try {
			
			//UserName
			driver.findElement(By.name("txtUName")).sendKeys("Preethi");
			Thread.sleep(100);
			
			//Password
			driver.findElement(By.name("txtPwd")).sendKeys("1234");
			Thread.sleep(100);
			
			//ConfirmPassword
			driver.findElement(By.className("Format")).sendKeys("1234");
			Thread.sleep(100);
		
		} catch (InterruptedException e) {
			
			System.out.println("Some Exception");		
		}
		
		//FirstName
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("Preethi");
		
		//LastName
		driver.findElement(By.name("txtLN")).sendKeys("Varsha");
		
		//Gender
		driver.findElement(By.cssSelector("input[value='Female']")).click();
		
		//DOB
		driver.findElement(By.name("DtOB")).sendKeys("31/03/1997");

		//Email
		driver.findElement(By.name("Email")).sendKeys("pree.varsha@igate.com");

		//Address
		driver.findElement(By.name("Address")).sendKeys("MV Nagar");
		
		//City
		Select drpCity = new Select(driver.findElement(By.name("City")));
		drpCity.selectByVisibleText("Chennai");
		drpCity.selectByIndex(1);
		drpCity.selectByIndex(2);
		
		//PhoneNo
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9999999999");
		
		//Hobbies
		List<WebElement> element = driver.findElements(By.name("chkHobbies"));
		for(WebElement val : element) {
			
			val.click();
			
			try {
				
				Thread.sleep(500);
			
			} catch (InterruptedException ex) {

				System.out.println(ex.getMessage());			}
		}
		
		//Examples of get commands
		String actualTitle;
		actualTitle = driver.getTitle();
		System.out.println("The page title is :" + actualTitle);
		String expectedTitle = "Email Registration Form";
		
		Boolean b = driver.getPageSource().contains("Email Registration Form");
		
		if(b==true) {
			System.out.println("Passed");
		}
		else {
			System.out.println("Failed");
		}
		
		String currentURL;
		currentURL = driver.getCurrentUrl();
		System.out.println("The page current URL is :" + currentURL);
		
		//Submit
		driver.findElement(By.name("submit")).click();
		
		driver.close();		
	}

}
