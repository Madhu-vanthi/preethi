package com.cg.selenium;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Registration {

	public static void main(String[] args) {		
			
			String driverPath = "D:\\Lesson 5-HTML Pages\\chromedriver_win32\\";
			
			System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
			WebDriver driver = new ChromeDriver();
			
			driver.get("file:///D:/Users/ADM-IG-HWDLAB2E/Downloads/registration.html");
			
			//FirstName
			driver.findElement(By.name("firstName")).sendKeys("Preethi");
			
			//LastName
			driver.findElement(By.name("lastName")).sendKeys("Sr");
			
			//Password
			driver.findElement(By.name("password")).sendKeys("1234");		
			
			//Re-EnterPassword
			driver.findElement(By.className("Format")).sendKeys("1234");	
			
			//Email
			driver.findElement(By.name("emailId")).sendKeys("pree.sr@igate.com");			
			
			//PhoneNo
			driver.findElement(By.name("mobileNo")).sendKeys("9999999999");
			
			//Gender
			driver.findElement(By.cssSelector("input[value='male']")).click();
			
			//Communication
			driver.findElement(By.cssSelector("input[value='mobile']")).click();
			
			//City
			Select drpGraduation = new Select(driver.findElement(By.name("graduation")));
			drpGraduation.selectByVisibleText("BE");
			
			String currentURL;
			currentURL = driver.getCurrentUrl();
			System.out.println("The page current URL is :" + currentURL);
			
			//Submit
			driver.findElement(By.name("submit")).click();
			driver.navigate().to("file:///D:/Users/ADM-IG-HWDLAB2E/Downloads/registrationSuccessPage.html");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			driver.close();		
		}


	
}
