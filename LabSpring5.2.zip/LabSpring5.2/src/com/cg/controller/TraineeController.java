package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Login;
import com.cg.dto.Trainee;
import com.cg.service.ITraineeService;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {
	ArrayList<String> traineeDomain = null;
	@Autowired
	ITraineeService traineeService = new TraineeService();

	public ITraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@RequestMapping(value = "/ShowLoginPage", method = RequestMethod.GET)
	public String displayLoginPage(Model model) {
		Login lg = new Login();
		model.addAttribute("log", lg);
		model.addAttribute("compNameObj", "Training");
		return "Login";
	}

	@RequestMapping(value = "/ValidateUser.obj", method = RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value = "log") Login log, BindingResult result, Model model) {
		if (log.getUserName().equalsIgnoreCase("a") && log.getPassword().equalsIgnoreCase("a")) {
			return "TMSPage";
		} else {
			model.addAttribute("message", "Invalid credentials");
			return "ErrorPage";
		}
	}

	@RequestMapping(value = "/AddTrainee", method = RequestMethod.GET)
	public String addUserDetails(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "AddPage";
	}

	@RequestMapping(value = "/InsertTrainee", method = RequestMethod.POST)
	public String insertUserDetails(@ModelAttribute(value="trainee") Trainee trainee, Model model) {
		traineeService.addTrainee(trainee);
		model.addAttribute("message", "Trainee added");
		return "AddPage";
		/*if (traineeService.addTrainee(trainee) == null) {
			model.addAttribute("message", "Not able to insert user");
			return "AddPage";
		} else {

		}*/
	}
	@RequestMapping(value = "/DeletePage", method = RequestMethod.GET)
	public String deleteUserDetails11(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "DeletePage";
	}
	@RequestMapping(value = "/DeleteTraineeShow.obj", method = RequestMethod.POST)
	public String deleteShowUserDetails(@ModelAttribute(value="trainee") Trainee trainee, Model model) {
		trainee=traineeService.findTrainee(trainee.getTraineeId());
		traineeService.deleteTrainee(trainee.getTraineeId());
		model.addAttribute("trainee", trainee);
		return "DeletePage";
	}
		@RequestMapping(value = "/DeleteTrainee.obj", method = RequestMethod.POST)
	public String deleteUserDetails(@ModelAttribute(value="trainee") Trainee trainee, Model model) {
			model.addAttribute("message", "Trainee deleted");
			return "DeletePage";
		}
	@RequestMapping(value = "/ModifyPage", method = RequestMethod.GET)
	public String updateDetails(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "ModifyPage";
	}
	/*@RequestMapping(value = "/ModifyTraineeShow.obj", method = RequestMethod.POST)
	public String updateShowUserDetails(@ModelAttribute(value="trainee") Trainee trainee, Model model) {
		trainee=traineeService.findTrainee(trainee.getTraineeId());
		model.addAttribute("trainee", trainee);
		return "ModifyPage";
	}*/
	@RequestMapping(value = "/ModifyTrainee.obj", method = RequestMethod.POST)
	public String updateUserDetails(@ModelAttribute(value="trainee") Trainee trainee, Model model) {
		trainee=traineeService.findTrainee(trainee.getTraineeId());
		model.addAttribute("trainee", trainee);
		return "ModifyPage";
	}
	@RequestMapping(value = "/ModifiedTrainee.obj", method = RequestMethod.POST)
	public String updatedUserDetails(@ModelAttribute(value="trainee") Trainee trainee, Model model) {
		trainee=traineeService.updateTrainee(trainee);
		model.addAttribute("message", "trainee updated");
		return "ModifyPage";
	}
	
	@RequestMapping(value = "/RetrivePage", method = RequestMethod.GET)
	public String getUserDetails(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "RetrivePage";
	}

	@RequestMapping(value = "/RetriveTrainee.obj", method = RequestMethod.POST)
	public String displayUserDetails(@ModelAttribute(value="trainee") Trainee trainee, Model model) {
				trainee=traineeService.findTrainee(trainee.getTraineeId());
		if(trainee!=null) {
			model.addAttribute("message", "Trainee Details");
			model.addAttribute("trainee", trainee);
			return "RetrivePage";} 
		else{
			model.addAttribute("message", "Trainee cant be displayed");
			return "RetrivePage";
		}
	}

	@RequestMapping(value = "/RetriveAllTrainee.obj", method = RequestMethod.GET)
	public String displayAllUserDetails(ArrayList<Trainee> trainees, Model model) {
			trainees=(ArrayList<Trainee>) traineeService.findAllTrainee();
			model.addAttribute("message", "All Trainee Details");
			model.addAttribute("traineeList", trainees);
			return "RetriveAllPage";
		
	}


}