package com.cg.service;

import java.util.List;

import com.cg.dto.Trainee;

public interface ITraineeService {
	public Trainee addTrainee(Trainee trainee);
	public Trainee deleteTrainee(String traineeId);
	public Trainee updateTrainee(Trainee trainee);
	public Trainee findTrainee(String traineeId);
	public List<Trainee> findAllTrainee();
}
