package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ITraineeDao;
import com.cg.dao.TraineeDao;
import com.cg.dto.Trainee;
@Service("traineeService")
public class TraineeService implements ITraineeService {
	@Autowired
	ITraineeDao traineeDao=new TraineeDao();  
	
	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public Trainee addTrainee(Trainee trainee) {
		return traineeDao.addTrainee(trainee);
	}

	@Override
	public Trainee deleteTrainee(String traineeId) {
		return traineeDao.deleteTrainee(traineeId);
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
		return traineeDao.updateTrainee(trainee);
	}

	@Override
	public Trainee findTrainee(String traineeId) {
		return traineeDao.findTrainee(traineeId);
	}

	@Override
	public List<Trainee> findAllTrainee() {
		return traineeDao.findAllTrainee();
	}

}
