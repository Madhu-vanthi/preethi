package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Trainee;
@Repository("traineeDao")
@Transactional
public class TraineeDao implements ITraineeDao {
	@PersistenceContext
	EntityManager entityManager =null;

	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public Trainee addTrainee(Trainee trainee) {
		entityManager.persist(trainee);
		return trainee;
	}

	@Override
	public Trainee deleteTrainee(String id) {
		Trainee trainee=this.findTrainee(id);
		entityManager.remove(trainee);
		return trainee;
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
		//int i= entityManager.createQuery("update trainee set traineeDomain="+trainee.getTraineeDomain()+"where traineeid="+trainee.getTraineeId(),Trainee.class).executeUpdate()/*.getSingleResult()*/;
		entityManager.merge(trainee);
		return trainee;
		 //entityManager.createNamedQuery("update trainee",Trainee.class).se
			}

	@Override
	public Trainee findTrainee(String traineeId) {
		return entityManager.find(Trainee.class, traineeId);
	}

	@Override
	public List<Trainee> findAllTrainee() {
		return entityManager.createQuery("from Trainee t").getResultList();
	}

}
