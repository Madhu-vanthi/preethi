package com.cg.dao;

import java.util.List;

import com.cg.dto.Trainee;

public interface ITraineeDao {
	public Trainee addTrainee(Trainee trainee);
	public Trainee deleteTrainee(String id);
	public Trainee updateTrainee(Trainee trainee);
	public Trainee findTrainee(String id);
	public List<Trainee> findAllTrainee();
}
