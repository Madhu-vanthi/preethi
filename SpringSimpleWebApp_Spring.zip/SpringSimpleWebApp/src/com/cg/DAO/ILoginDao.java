package com.cg.DAO;

import java.util.ArrayList;

import com.cg.DTO.Login;
import com.cg.DTO.Register;

public interface ILoginDao {

	public boolean isUserExist(String usn);
	public Login validateUser(Login login);
	public Register insertUserDetails(Register userDetails);
	public ArrayList<Register> getAllUserDetails();
	public Register deleteUsers(String usr);

	
}
