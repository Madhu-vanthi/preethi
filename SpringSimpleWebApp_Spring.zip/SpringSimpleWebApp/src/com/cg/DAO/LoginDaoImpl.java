package com.cg.DAO;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.DTO.Login;
import com.cg.DTO.Register;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	EntityManager entityManager=null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExist(String usn) {
		
		Login usr=entityManager.find(Login.class,usn);
		
		if(usr!=null){
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public Login validateUser(Login login) {
		
		Login usr=entityManager.find(Login.class, login.getUserName());

		return usr;
	}

	@Override
	public Register insertUserDetails(Register userDetails) {
		
		Login login=new Login();
		login.setUserName(userDetails.getUname());
		login.setPassword(userDetails.getPwd());
		
		StringBuffer str=new StringBuffer();
		
		for (String tempStr:userDetails.getSkillSet()){
			
			str.append(tempStr+",");
			//str+=tempStr+",";			
		}
		userDetails.setSkillSetStr(str.toString());
		entityManager.persist(userDetails);
		entityManager.persist(login);
		entityManager.flush();
		Register rg=entityManager.find(Register.class,userDetails.getUname());
		return rg;
	}

	@Override
	public ArrayList<Register> getAllUserDetails() {

		String qry=" SELECT rg FROM Register rg ";
		TypedQuery tq=entityManager.createQuery(qry,Register.class);
		ArrayList<Register> uList=(ArrayList)tq.getResultList();
		return uList;
	}

	@Override
	public Register deleteUsers(String usr) {

		Register redDto=entityManager.find(Register.class, usr);
		Login logDto=entityManager.find(Login.class, usr);
		entityManager.remove(redDto);
		entityManager.remove(logDto);
		entityManager.flush();
		
		return redDto;
	}

	
}
