package com.cg.DTO;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="cg_users")
public class Login {

	@Id
	@Column(name="user_name", length=20)
	@NotNull(message="User Name Is Mandatory")
	private String userName;
	
	@Column
	@NotNull(message="Password Is Mandatory")
	private String password;
	
	public Login() {}
	
	@NotEmpty(message="User Name Is Mandatory")
	@Size(min=5,message="min 5 character require in username require")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@NotEmpty(message="Password Is Mandatory")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
