package com.cg.ctrl;

import java.util.ArrayList;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.DTO.Login;
import com.cg.DTO.Register;
import com.cg.service.ILoginService;

@Controller
public class LoginController {

	ArrayList<String> cityList=null;
	ArrayList<String> skillSet=null;
	
	@Autowired
	ILoginService loginService=null;	

	public ILoginService getLoginService() {
		return loginService;
	}

	public void setLoginService(ILoginService loginService) {
		this.loginService = loginService;
	}

	@RequestMapping(value="/showLoginPage", method=RequestMethod.GET)
	public String displayLoginPage(Model model) {
		
		Login lg=new Login();
		lg.setUserName("Enter your user name here:");
		model.addAttribute("log",lg);
		model.addAttribute("compNameObj","Capgemini");
		return "showLoginPage";
	}
	
	/************************Validate User***************************/
	
	@RequestMapping(value="/ValidateUser", method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="log")@Valid Login lg, BindingResult result, Model model){
		
		if(result.hasErrors()) {
			return "showLoginPage";			
		}
		else {
			
			if(loginService.isUserExist(lg.getUserName())) {
				Login user=loginService.validateUser(lg);
				if(user != null) {
			
					model.addAttribute("unmObj", lg.getUserName());
					return "Success";
				}
				else {
					return "Failure";
				}
			}
			else {
				return "redirect:/RegistrationPage.obj";
			}
		
		}
	}	
	
	/************************Validate User***************************/

	@RequestMapping(value="/RegistrationPage", method=RequestMethod.GET)
	public String displayRegPage(Model model) {
		
		cityList = new ArrayList<>();
		cityList.add("pune");
		cityList.add("Nagpur");
		cityList.add("Mumbai");
		cityList.add("Noida");

		skillSet = new ArrayList<>();
		skillSet.add("Java");
		skillSet.add("Dotnet");
		skillSet.add("Oracle");
		skillSet.add("Html");
		skillSet.add("BI");

		Register reg=new Register();
		model.addAttribute("rg",reg);
		model.addAttribute("cList",cityList);
		model.addAttribute("sList",skillSet);
		return "RegistrationPage";
	}
	
	/************************InsertUser.obj***************************/

	@RequestMapping(value="InsertUser.obj", method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="rg")@Valid Register reg, BindingResult result, Model model) {
	{
			loginService.insertUserDetails(reg);	
			ArrayList<Register> userList=loginService.getAllUserDetails();
			model.addAttribute("userListObj",userList);		
			return "ListAllUser";
		}
	}
	
	/************************DeleteUser.obj***************************/
	
	@RequestMapping(value="deleteUser.obj", method=RequestMethod.GET)
	public String deleteUsers(@RequestParam(value="uid")String unm, Model model) {
		
		Register rd=loginService.deleteUsers(unm);
		if(rd!=null) {
			ArrayList<Register> userList=loginService.getAllUserDetails();
			model.addAttribute("userListObj", userList);
			model.addAttribute("MsgObj", "Data Deleted");
			return "ListAllUser";
		}
		else {
			return "Error";
		}
			
			
	}
	
}
