package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.DAO.ILoginDao;
import com.cg.DTO.Login;
import com.cg.DTO.Register;

@Service("loginService")
public class LoginServiceImpl implements ILoginService{

	@Autowired
	ILoginDao loginDao = null;
	
	@Override
	public boolean isUserExist(String usn) {
		
		return loginDao.isUserExist(usn);
	}
	
	public ILoginDao getLoginDao() {
		return loginDao;
	}

	public void setLoginDao(ILoginDao loginDao) {
		this.loginDao = loginDao;
	}

	@Override
	public Login validateUser(Login login) {
		
		Login dbUser = loginDao.validateUser(login);
		if((login.getUserName().equalsIgnoreCase(dbUser.getUserName())) && 
				(login.getPassword().equalsIgnoreCase(dbUser.getPassword())) ) {
			
			return login;
		}
		
		else {
			return null;
		}
	}
	
	@Override
	public Register insertUserDetails(Register userDetails) {
		return loginDao.insertUserDetails(userDetails);
	}

	@Override
	public ArrayList<Register> getAllUserDetails() {
		return loginDao.getAllUserDetails();
	}

	@Override
	public Register deleteUsers(String usr) {
		return loginDao.deleteUsers(usr);
	}
	
}
