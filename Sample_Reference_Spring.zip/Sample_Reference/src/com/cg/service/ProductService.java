package com.cg.service;
import java.util.List;

import com.cg.entities.Cart;
import com.cg.entities.ProductOne;
public interface ProductService {
	
	public List<ProductOne> getAllProducts();

	ProductOne getProductById(int productId);

	public ProductOne deleteProduct(int i);
	
	//void addProduct(Product product);
	
	void editProduct(ProductOne product);

	public Object findAll();

	public Object find(int id);

	public Object updateCart(String cart);

	public Cart updateCart(Cart cart);

	
		
	}

	

	


