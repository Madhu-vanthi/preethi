package com.cg.entities;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
//@Table(name = "cart")
@Entity
public class Cart {
	@Id
	private int userid;
	private int productid;
	private String name;
	private int price;
	private String category;
	
	
	
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "Cart [userid=" + userid + ", productid=" + productid + ", name=" + name + ", price=" + price
				+ ", category=" + category + "]";
	}
	public Cart(int userid, int productid, String name, int price, String category) {
		super();
		this.userid = userid;
		this.productid = productid;
		this.name = name;
		this.price = price;
		this.category = category;
	}
	public Cart() {
		// TODO Auto-generated constructor stub
	}
	public Object getuserid() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}


