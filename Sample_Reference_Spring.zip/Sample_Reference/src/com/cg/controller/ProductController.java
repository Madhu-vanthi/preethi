package com.cg.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.entities.Cart;
import com.cg.entities.ProductOne;
import com.cg.service.ProductService;
import com.cg.service.ProductServiceImpl;
@Controller
public class ProductController { 
@Autowired
  ProductService productService=new ProductServiceImpl();
	
	public ProductService getProductService() {
		return productService;
	}

	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

	@RequestMapping(value = "/productlist", method=RequestMethod.GET)
	public String displayProduct(Model model) {
		List<ProductOne>userList=productService.getAllProducts();
		model.addAttribute("userListObj",userList);
		return"ListAllProduct";
	}
	
	@RequestMapping(value="/addtocart",method=RequestMethod.GET)
    public String updateUser(Model model, @ModelAttribute(value= "uid")String productid) {
		List<ProductOne>userList=productService.getAllProducts();
        productService.deleteProduct(Integer.parseInt(productid));
        model.addAttribute("userList2", userList);
        return "ListAllCart";
        }
	
	
	/*@RequestMapping(value="/addtocart", method = RequestMethod.POST)
	public ModelAndView addToChart(){
	    ModelAndView cart = new ModelAndView("Cart");
	    return cart;  
	    */
	    /*@RequestMapping(value="/add", method = RequestMethod.POST)
		public String postAdd(@RequestParam("file")MultipartFile file,@RequestParam("id")Integer categoryId,@ModelAttribute("itemAttribute")Item item) throws IOException{
			
			itemService.add(categoryId, item,file);
			return "redirect:/category/list";
		}*/

	}
	





