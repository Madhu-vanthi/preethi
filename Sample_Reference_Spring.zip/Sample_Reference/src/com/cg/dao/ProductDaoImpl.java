package com.cg.dao;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.Cart;
import com.cg.entities.ProductOne;
import com.sun.org.apache.regexp.internal.recompile;

@Repository(value = "productDao")
@Transactional
public class ProductDaoImpl implements ProductDao {
@PersistenceContext
EntityManager entityManager=null;
	public EntityManager getEntityManager() {
	return entityManager;
}
public void setEntityManager(EntityManager entityManager) {
	this.entityManager = entityManager;
	
}
	@Override
	public List<ProductOne> getAllProducts() {
		String qry="from ProductOne pro";
		List<ProductOne> uList=(List<ProductOne>) 
		entityManager.createQuery(qry,ProductOne.class).getResultList();
		return uList;
		}
	@Override
	public ProductOne getProductById(String productId) {
		return entityManager.find(ProductOne.class,productId);
	}

	@Override
	public ProductOne deleteProduct(int productId) {
		ProductOne pro=entityManager.find(ProductOne.class, productId);
		entityManager.remove(pro);
		entityManager.flush();
		return pro;
		
	}
	/*@Override
	public void addProduct(Product product) {
		entityManager.add(product);
		entityManager.close();
	}*/
	@Override
	public Cart updateCart(Cart cart) {
		entityManager.find(ProductOne.class,cart.getProductid());
		Cart ct=entityManager.merge(cart);
		entityManager.flush();
		return ct;
		
	}

	
}

	
	