package com.cg.dao;
import java.util.List;

import com.cg.entities.Cart;
import com.cg.entities.ProductOne;

public interface ProductDao {

	List<ProductOne> getAllProducts();

	public ProductOne getProductById(String productId);

	public ProductOne deleteProduct(int productId);
	
	public Cart updateCart(Cart cart);

	//void addProduct(Product product);
	

	
}

