package com.cg.project.bean;

import java.util.List;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class Owner {	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int custNo;	
	private String firstName,lastName,email;
	@OneToMany
	private List<Bike> bikes;
	public Owner() {}
	public Owner(int custNo, String firstName, String lastName, String email, List<Bike> bikes) {
		super();
		this.custNo = custNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.bikes = bikes;
	}
	public int getCustNo() {
		return custNo;
	}
	public void setCustNo(int custNo) {
		this.custNo = custNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Bike> getBikes() {
		return bikes;
	}
	public void setBikes(List<Bike> bikes) {
		this.bikes = bikes;
	}
	
}
