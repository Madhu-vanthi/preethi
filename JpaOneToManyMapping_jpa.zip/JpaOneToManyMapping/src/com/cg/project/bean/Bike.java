package com.cg.project.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Bike {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int carCode;
	private int price;
	private String carType;
	@ManyToOne
	private Owner owner;
	public Bike() {}
	public Bike(int carCode, int price, String carType, Owner owner) {
		super();
		this.carCode = carCode;
		this.price = price;
		this.carType = carType;
		this.owner = owner;
	}
	public int getCarCode() {
		return carCode;
	}
	public void setCarCode(int carCode) {
		this.carCode = carCode;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCarType() {
		return carType;
	}
	public void setCarType(String carType) {
		this.carType = carType;
	}
	public Owner getOwner() {
		return owner;
	}
	public void setOwner(Owner owner) {
		this.owner = owner;
	}
	

}
