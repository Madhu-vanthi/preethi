package com.cg.bean;

import java.util.ArrayList;

public class Emp {

	private int empId;
	private String empName;
	private float empSalary;
	private ArrayList<Address> empAdd;
	public Emp() {}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(float empSalary) {
		this.empSalary = empSalary;
	}
	public ArrayList<Address> getEmpAdd() {
		return empAdd;
	}
	public void setEmpAdd(ArrayList<Address> empAdd) {
		this.empAdd = empAdd;
	}
	
}
