package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmpDemo {
	public static void main(String args[]) {
	
		ApplicationContext ctx=new ClassPathXmlApplicationContext("CgBeans.xml");

		Employee emp1=(Employee)ctx.getBean("PreethiObj");
		System.out.println("----Employee Info----");
		System.out.println(" ID: "+emp1.getEmpId()+" Name: "+emp1.getEmpName()+" Salary: "+emp1.getEmpSalary()+" EmployeeAddress : "
				+emp1.getEmpAdd().getCity()+", "+emp1.getEmpAdd().getState()+", "+emp1.getEmpAdd().getZipCode()+".");
		
		System.out.println("--------------------------------------------------------------------------------------------");
		Emp emp2=(Emp)ctx.getBean("MadheshObj");
		System.out.println("----Emp Info----");
		System.out.println(" ID: "+emp2.getEmpId()+" Name: "+emp2.getEmpName()+" Salary: "+emp2.getEmpSalary()+" EmployeeAddress : "
				+emp2.getEmpAdd()+".");
		
	}

}
