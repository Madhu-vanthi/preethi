package com.cg.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestReadPropertyAnnotationDemo {

	public static void main(String args[]) {

		//ApplicationContext ctx=new ClassPathXmlApplicationContext("CgXmlAnnotation.xml");
		
		ApplicationContext ctx=SpringApplication.run(TestReadPropertyAnnotationDemo.class, args);
		
		User myCredentials=(User)ctx.getBean("u1");
		System.out.println(myCredentials);

	}
}
