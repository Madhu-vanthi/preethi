package com.cg.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emp1")
public class Employee {

	@Value("54526")
	private int empId;
	
	@Value("Maddy")
	private String empName;
	
	@Value("25000")
	private float empSalary;
	
	@Autowired
	@Qualifier("getAddress2")
	private Address empAdd;
	
	public Employee() {}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(float empSalary) {
		this.empSalary = empSalary;
	}
	public Address getEmpAdd() {
		return empAdd;
	}
	public void setEmpAdd(Address empAdd) {
		this.empAdd = empAdd;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empAdd=" + empAdd
				+ "]";
	}
	
}
