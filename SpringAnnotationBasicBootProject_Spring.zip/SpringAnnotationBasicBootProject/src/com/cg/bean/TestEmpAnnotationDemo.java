package com.cg.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

//import org.springframework.context.support.ClassPathXmlApplicationContext;

@ComponentScan(basePackages="com.cg.bean")
public class TestEmpAnnotationDemo {

	public static void main(String[] args) {
		
		//ApplicationContext ctx=new ClassPathXmlApplicationContext("CgXmlAnnotation.xml");
		
		ApplicationContext ctx=SpringApplication.run(TestEmpAnnotationDemo.class, args);
		Employee e1=(Employee)ctx.getBean("getAddress2");
		System.out.println(e1);
		
		System.out.println("----------------------------------------------");
		Emp e2=(Emp)ctx.getBean("emp2");
		System.out.println(e2);
		
		System.out.println("----------------------------------------------");
		Employee e3=(Employee)ctx.getBean("offemp2");
		System.out.println(e3);

		User myCredentials=(User)ctx.getBean("u1");
		System.out.println(myCredentials);


	}

}
