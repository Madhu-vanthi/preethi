package com.cg.bean;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
public class SpringConfig {

	@Bean
	public ArrayList<Address> getAddList(){
		Address ad1=new Address();
		ad1.setCity("Bangalore");
		ad1.setState("Karnataka");
		ad1.setZipCode(454136);
		
		Address ad2=new Address();
		ad2.setCity("Pune");
		ad2.setState("Maharastra");
		ad2.setZipCode(411029);
		
		ArrayList<Address> adList=new ArrayList<Address>();
		adList.add(ad1);
		adList.add(ad2);
		return adList;
		
	}
	
	/*--------------------------------------------------------------------*/
	@Bean
	public Address getAddress2() {
		Address ad=new Address();
		ad.setCity("Chennai");
		ad.setState("TN");
		ad.setZipCode(600028);
		return ad;
	}

	/*--------------------------------------------------------------------*/
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
		
	}
	
}
