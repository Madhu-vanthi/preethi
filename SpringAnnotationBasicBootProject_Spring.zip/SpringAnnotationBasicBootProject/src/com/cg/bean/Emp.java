package com.cg.bean;

import java.util.ArrayList;

import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emp2")
public class Emp {

	@Value("54431")
	private int empId;
	
	@Value("Preethi")
	private String empName;
	
	@Value("2000")
	private float empSalary;
	
	@Resource(name="getAddList")
	private ArrayList<Address> empAdd;
	
	public Emp() {}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(float empSalary) {
		this.empSalary = empSalary;
	}
	public ArrayList<Address> getEmpAdd() {
		return empAdd;
	}
	public void setEmpAdd(ArrayList<Address> empAdd) {
		this.empAdd = empAdd;
	}
	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empAdd=" + empAdd + "]";
	}
	
}
