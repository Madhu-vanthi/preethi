package com.cg.staticdb;

import java.util.ArrayList;

import com.cg.bean.Country;

public class CountryDb {
	private static ArrayList<Country> countryList=new ArrayList<Country>();
	static {
		countryList.add(new Country("111", "India", "324242"));
		countryList.add(new Country("112", "America", "534566"));
		countryList.add(new Country("113", "Nepal", "446764"));
		countryList.add(new Country("114", "Bhutan", "678754"));
		countryList.add(new Country("115", "China", "378989"));
	}
	public static ArrayList<Country> getCountryList(){
		return countryList;
	}
	public static void setCountryList(ArrayList<Country> countryList) {
		CountryDb.countryList = (ArrayList<Country>)countryList;
	}
	
}
