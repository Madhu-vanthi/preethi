package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Value;

@Entity
@Table(name="ScheduledSessions")
public class ScheduledSessions {	
	
	@Id
	@Value("${db.id}")
	private int id;
	
	@Value("${db.sessionName}")
	private String sessionName;
	
	//@Column(name="duration", length=20)
	@Value("${db.duration}")
	private int duration;

	//@Column(name="faculty", length=20)
	@Value("${db.faculty}")
	private String faculty;

	//@Column(name="id", length=20)
	@Value("${db.mode}")
	private String mode;

	public ScheduledSessions() {}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}	
	
}
