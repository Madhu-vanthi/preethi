package com.cg.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.dto.ScheduledSessions;

@Repository
@Transactional
public class SessionDaoImpl implements ISessionDao{

	@PersistenceContext
	EntityManager entityManager =null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	@Override
    public List<ScheduledSessions> getAllSessions() {       

        return entityManager.createQuery("from ScheduledSessions ss", ScheduledSessions.class).getResultList();
		
    }

}
