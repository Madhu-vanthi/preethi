package com.cg.dao;

import java.util.List;

import com.cg.dto.ScheduledSessions;

public interface ISessionDao {
	
	public List<ScheduledSessions> getAllSessions();
	
}
