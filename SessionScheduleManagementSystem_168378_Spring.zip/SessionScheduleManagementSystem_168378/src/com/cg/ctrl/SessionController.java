package com.cg.ctrl;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.dto.ScheduledSessions;
import com.cg.service.ISessionService;

@Controller
public class SessionController {

	@Autowired
	ISessionService sessionSer;

	public ISessionService getSessionSer() {
		return sessionSer;
	}

	public void setSessionSer(ISessionService sessionSer) {
		this.sessionSer = sessionSer;
	}	
	
	@RequestMapping(value = "/showEnrollPage", method = RequestMethod.GET)
	public String displayAllSessionDetails(ArrayList<ScheduledSessions> sessions, Model model) {
			sessions=(ArrayList<ScheduledSessions>)sessionSer.getAllSessions();			
			model.addAttribute("sessionList", sessions);
			return "ScheduledSessions";
		
	}
	
	@RequestMapping(value = "/enrollMe", method = RequestMethod.GET)
	public String Enrollment(@ModelAttribute(value="sessionList")ScheduledSessions enroll,Model model) {		

		model.addAttribute("sessionName", enroll.getSessionName());	
		return "Success";
	}	 
	
}
