package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ISessionDao;
import com.cg.dto.ScheduledSessions;

@Service
public class SessionServiceImpl implements ISessionService{

	@Autowired
	ISessionDao sessionDao;
	
	public ISessionDao getSessionDao() {
		return sessionDao;
	}

	public void setSessionDao(ISessionDao sessionDao) {
		this.sessionDao = sessionDao;
	}
	
	@Override
	public List<ScheduledSessions> getAllSessions() {
		return sessionDao.getAllSessions();
	}
	

}
