package com.cg.service;

import java.util.List;

import com.cg.dto.ScheduledSessions;

public interface ISessionService {

	public List<ScheduledSessions> getAllSessions();

}
