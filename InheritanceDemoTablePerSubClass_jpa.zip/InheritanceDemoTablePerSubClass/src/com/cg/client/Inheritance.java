package com.cg.client;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.beans.Employee;
import com.cg.beans.PEmployee;

public class Inheritance {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");      

		
	}

}
