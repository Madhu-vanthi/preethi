package com.cg.iodemo;

import java.io.Serializable;

public class Associate implements Serializable{
	
	private int associateId, basicsalary;
	private String firstname, lastName;
	
	public Associate() {}

	public Associate(int associateId, int basicsalary, String firstname, String lastName) {
		super();
		this.associateId = associateId;
		this.basicsalary = basicsalary;
		this.firstname = firstname;
		this.lastName = lastName;
	}

	public int getAssociateId() {
		return associateId;
	}

	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}

	public int getBasicsalary() {
		return basicsalary;
	}

	public void setBasicsalary(int basicsalary) {
		this.basicsalary = basicsalary;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", basicsalary=" + basicsalary + ", firstname=" + firstname
				+ ", lastName=" + lastName + "]";
	}
	
	

}
