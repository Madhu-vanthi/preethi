package com.cg.iodemo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MainClass {

	public static void main(String[] args) {
		
	/*File file = new File("d:\\dataFile.txt");
		try {
			
			file.createNewFile();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		System.out.println(file.canWrite());
		System.out.println(file.getName());
		System.out.println(file.canExecute());	*/
		
		try {
			
			File file = new File("d:\\AssociateData.txt");
			ObjectSerializationDemo.doSerialization(file);
			
			ObjectSerializationDemo.doDeSerialization(file);
			
		} catch (IOException | ClassNotFoundException e) {
		
			e.printStackTrace();
		} 
		
	}

}
