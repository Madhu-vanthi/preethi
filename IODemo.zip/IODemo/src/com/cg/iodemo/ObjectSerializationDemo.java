package com.cg.iodemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectSerializationDemo {

	public static void doSerialization(File file) throws FileNotFoundException, IOException{
		Associate associate = new Associate(111,12500,"madhu","vanthi");
		try(ObjectOutputStream destWriter = new ObjectOutputStream(new FileOutputStream(file))){
			destWriter.writeObject(associate);
			System.out.println("Associate object has writen on "+file.getAbsolutePath());
		}
	}
	public static void doDeSerialization(File file) throws FileNotFoundException, IOException, ClassNotFoundException{
		try(ObjectInputStream srcReader = new ObjectInputStream(new FileInputStream(file))){
			Associate associate = (Associate)srcReader.readObject();
			System.out.println(associate);
		}
	}
	
}
