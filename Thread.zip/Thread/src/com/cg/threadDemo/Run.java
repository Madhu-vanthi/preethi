package com.cg.threadDemo;

public class Run implements Runnable{

	@Override
	public void run() {
		Thread t = Thread.currentThread();
		for(int i=0;i<=100;i++)
			if(t.getName().equals("th1") && i%2==0) {				
					System.out.println("even no's:   " +i+ " " +t.getName());
			}
			else {				
				System.out.println("odd no's:   " +i+ " " +t.getName());
			}
		
	}	

}
