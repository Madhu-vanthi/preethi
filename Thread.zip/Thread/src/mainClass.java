import com.cg.threadDemo.Run;
import com.cg.threadDemo.RunnableResource;

public class mainClass {
	public static void main(String args[]) {
		RunnableResource r = new RunnableResource();
		Run run = new Run();
		
		Thread th1 = new Thread(run,"th1");
		th1.start();
		
		Thread th2 = new Thread(run,"th2");
		th2.start();
		
	}
}
