package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		BankingServices bankingServices=new BankingServicesImpl();
		try {
			Account account1=bankingServices.openAccount("savings", 500.0f);	
			Account account2=bankingServices.openAccount("current", 5000.0f);
			System.out.println(account1);
			System.out.println(bankingServices.depositAmount(account1.getPinNumber(),5000));
			System.out.println(bankingServices.withdrawAmount(1001,2500,account1.getPinNumber()));
			System.out.println(bankingServices.fundTransfer(1001,1002,5000,account1.getPinNumber()));
			System.out.println(bankingServices.getAccountDetails(1001));
			System.out.println(bankingServices.getAllAccountDetails());
			System.out.println(bankingServices.getAccountAllTransaction(1001));
			System.out.println(bankingServices.accountStatus(1001));
				
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException
				| AccountNotFoundException | AccountBlockedException | InsufficientAmountException
				| InvalidPinNumberException e) {
			
			e.printStackTrace();
		}			

		
	}
}
