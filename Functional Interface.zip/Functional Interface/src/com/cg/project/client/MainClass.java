package com.cg.project.client;

import com.cg.project.lambdaInterface.FunctionalInterface1;
import com.cg.project.lambdaInterface.FunctionalInterface2;
import com.cg.project.lambdaInterface.FunctionalInterface3;
import com.cg.project.lambdaInterface.WorkService;

public class MainClass {

	public static void main(String[] args) {	
		
		FunctionalInterface1 ref1 = (a,b)->a+b;
		System.out.println(ref1.add(100,200));
		
		FunctionalInterface2 ref2 = (fName, lName) -> System.out.println(fName+" "+lName);
		ref2.greatUser("madhu","vanthi");
		

		FunctionalInterface3 ref3 = (str) -> str.toUpperCase();
		System.out.println(ref3.UpperCase("hello world"));
		
		callForWork(() -> System.out.println("Doing Some Work"));
		
		/*Runnable r = ()->{
		for(int i=0;i<10;i++)
			System.out.println("Tick "+i);};		
		Thread th1 = new Thread(r);
		th1.start();	*/
	
		/*Thread th2 = new Thread(()->{
		for(int i=0;i<10;i++)
			System.out.println("Tick "+i);});
		th2.start();	*/
	
		new Thread(()->{for(int i=0;i<10;i++)			
				System.out.println("Tick "+i);}).start();
		
	}		
		public static void callForWork(WorkService service) {
			service.doSomeWork();
	}		
		

}
