package com.cg.project.lambdaInterface;

@FunctionalInterface
public interface FunctionalInterface1 {
	
	int add(int a, int b);

}
