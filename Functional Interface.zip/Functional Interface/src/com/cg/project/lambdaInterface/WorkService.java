package com.cg.project.lambdaInterface;

public interface WorkService {
	
	void doSomeWork();

}
