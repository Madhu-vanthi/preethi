package com.cg.project.lambdaInterface;

@FunctionalInterface
public interface FunctionalInterface2 {
	
	void greatUser(String fName,String lName); 

}
