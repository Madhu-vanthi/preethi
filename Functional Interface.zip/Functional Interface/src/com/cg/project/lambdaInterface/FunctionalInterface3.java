package com.cg.project.lambdaInterface;

@FunctionalInterface
public interface FunctionalInterface3 {
	
	String UpperCase(String str) ;

}
