package com.cg.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.cg.bean.Book;
import com.cg.bean.MyBookConfig;

public class BookClient {

	public static void main(String args[]) {
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(MyBookConfig.class);
		Book book1=(Book)ctx.getBean("book");
		System.out.println(" Book HashCode : "+book1.hashCode());		
		System.out.println(" Book Info : "+book1);
		try {
			book1.cleanUp();
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		ctx.close();
	}
}
