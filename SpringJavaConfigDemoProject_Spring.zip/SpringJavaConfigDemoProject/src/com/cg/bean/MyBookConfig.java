package com.cg.bean;

import org.springframework.context.annotation.Bean;

public class MyBookConfig {

	@Bean
	public Author author() {
		return new Author("Kanetkar", "Nagpur");
	}
	
	@Bean(initMethod="setUp", destroyMethod="cleanUp")
	//@Scope("prototype")
	public Book book() {
		Book book=new Book();
		book.setYear("1997");
		book.setIsbn("kj77756");
		book.setAuthor(author());
		return book;
	}
}
