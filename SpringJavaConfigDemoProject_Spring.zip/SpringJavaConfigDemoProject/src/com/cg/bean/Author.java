package com.cg.bean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Author {

	private String authorName;
	private String address;
	public String getAuthorName() {
		return authorName;
	}
	public Author(String authorName, String address) {
		super();
		this.authorName = authorName;
		this.address = address;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	@PostConstruct
	public void customBookInit() {
		System.out.println("Method customBookInit() invoked.....");
	}
	
	@PreDestroy
	public void customBookDestroy() {
		 System.out.println("Method customBookDestroy() invoked.....");
	}
}
