package com.cg.beans;

public class Account {
	
	private long accNum;
	private double balance;
	private long n = 10000;
	private Person person;
	public Account() {}
	public Account(long accNum, double balance, Person person) {
		super();
		this.accNum = accNum;
		this.balance = balance;
		this.person = person;
	}
	public Account(double balance, Person person) {
		super();
		this.balance = balance;
		this.person = person;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public void deposit(double num) {
		setBalance(num+getBalance());
		System.out.println("Balance after deposition of money to Smith account: "+getBalance());
		
	}
	public void withdraw(double num) {
		setBalance(getBalance()-num);
		System.out.println("Balance after withdrawal of money from Kathy account: "+getBalance());
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance + ", person=" + getPerson().toString() + "]";
	}
	

}
