package com.cg.beans;

public class SavingsAccount extends Account {

	private final double minBalance = 500;
	public SavingsAccount() {}
	public SavingsAccount(long accNum, double balance, Person person) {
		super(accNum, balance, person);
		
	}
	public double getMinBalance() {
		return minBalance;
	}
	@Override
	public void deposit(double num) {
		
		super.deposit(num);
	}
	@Override
	public void withdraw(double num) {		
		super.withdraw(num);
		if(num<=this.minBalance) System.out.println("Can't perform withdraw option");
		
	}
	@Override
	public String toString() {
		return "SavingsAccount [minBalance=" + minBalance + "]";
	}	
	
}
