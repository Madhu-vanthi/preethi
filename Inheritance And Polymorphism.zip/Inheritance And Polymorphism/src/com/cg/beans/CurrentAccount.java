package com.cg.beans;

public class CurrentAccount extends Account{
	
	private int overDraftLimit;
	public CurrentAccount() {}
	public CurrentAccount(long accNum, double balance, Person person, int overDraftLimit) {
		super(accNum, balance, person);
		this.overDraftLimit = overDraftLimit;
		
	}
	public int getOverDraftLimit() {
		return overDraftLimit;
	}
	public void setOverDraftLimit(int overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}
	@Override
	public void withdraw(double num) {		
		super.withdraw(num);
		if(num==overDraftLimit) System.out.println("true");
	}
	@Override
	public String toString() {
		return "CurrentAccount [overDraftLimit=" + overDraftLimit + "]";
	}	
	
}
