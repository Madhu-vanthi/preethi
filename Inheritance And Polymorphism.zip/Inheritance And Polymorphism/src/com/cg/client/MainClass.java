package com.cg.client;

import com.cg.beans.Account;
import com.cg.beans.Person;

public class MainClass {
	public static void main(String[] args) {
		
		Account acc = new Account(45642,2000, new Person("Smith",30));			
		acc.deposit(2000);		
		
		Account  acc1= new Account(15642,3000, new Person("Kathy",45));		
		acc1.withdraw(2000);
		
		
		System.out.println(acc.toString()+"\n"+acc1.toString());
		
		
	}

}
