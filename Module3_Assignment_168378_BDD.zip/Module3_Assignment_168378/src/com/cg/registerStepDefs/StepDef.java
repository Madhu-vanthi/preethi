package com.cg.registerStepDefs;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.cg.pagebean.RegisterPageBeanFactory;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver driver;
	private RegisterPageBeanFactory obj;
	
	@Before
	public void openBrowsser() {

		String driverPath = "D:\\Lesson 5-HTML Pages\\chromedriver_win32\\";
		
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		WebDriver driver = new ChromeDriver();
		
		obj=new RegisterPageBeanFactory(driver);
		driver.get("file:///D:/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}
	
	@Given("^User is on Registeration page$")
	public void user_is_on_Registeration_page() throws Throwable {
	    
		obj=new RegisterPageBeanFactory(driver);
		driver.get("file:///D:/Lesson%205-HTML%20Pages/WorkingWithForms.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	    
		String title=driver.getTitle();
		if(title.contentEquals("Email")) System.out.println("****** Title Matched");
		else System.out.println("****** Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
	   
		obj.setPfuname("Preethi");	Thread.sleep(500);
	    obj.setPfpassword("1234");	Thread.sleep(500);
	    obj.setPfcpassword("1234");	Thread.sleep(500);
	    obj.setPffirstname("Preethi");	Thread.sleep(500);
	    obj.setPflastname("Varsha");	Thread.sleep(500);
	    driver.findElement(By.id("rbFemale")).click();	Thread.sleep(500);
	    obj.setPfdob("31/03/1997");	Thread.sleep(500);
	    obj.setPfemail("pree.varsha@gmail.com");	Thread.sleep(500);
	    obj.setPfaddress("MV Nagar");	Thread.sleep(500);
	    obj.setPfcity("Chennai");	Thread.sleep(500);
	    obj.setPfphone("9999999999");	Thread.sleep(500);
	    obj.setPfhobbies();	Thread.sleep(500);			
			
	    obj.setPfsubmit();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
	    
	}

	@After
	public void closeBrowsser() {
		
		driver.close();
	}
	
}
