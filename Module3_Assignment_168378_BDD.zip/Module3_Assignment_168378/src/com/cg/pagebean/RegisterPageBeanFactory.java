package com.cg.pagebean;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegisterPageBeanFactory {
	
	WebDriver driver;
	
	public RegisterPageBeanFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name="txtUName")
	@CacheLookup
	WebElement pfuname;
	
	@FindBy(name="txtPwd")
	@CacheLookup
	WebElement pfpassword;
	
	@FindBy(id="txtConfPassword")
	@CacheLookup
	WebElement pfcpassword;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement pffirstname;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement pflastname;
	
	@FindBy(name="name")
	@CacheLookup
	WebElement pfgender;
	
	@FindBy(name="DtOB")
	@CacheLookup
	WebElement pfdob;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement pfemail;
	
	@FindBy(name="Address")
	@CacheLookup
	WebElement pfaddress;
	
	@FindBy(name="City")
	@CacheLookup
	WebElement pfcity;
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement pfphone;
	
	@FindBy(name="chkHobbies")
	@CacheLookup
	WebElement pfhobbies;	
	
	@FindBy(name="submit")
	@CacheLookup
	WebElement pfsubmit;	
	
	
	public void setPfuname(String sfuname) {
		pfuname.sendKeys(sfuname);
	}

	public void setPfpassword(String sfpassword) {
		pfpassword.sendKeys(sfpassword);
	}

	public void setPfcpassword(String sfcpassword) {
		pfcpassword.sendKeys(sfcpassword);
	}

	public void setPffirstname(String sffirstname) {
		pffirstname.sendKeys(sffirstname);
	}

	public void setPflastname(String sflastname) {
		pflastname.sendKeys(sflastname);
	}

	public void setPfgender() {
		pfgender.click();
	}

	public void setPfdob(String sfdob) {
		pfdob.sendKeys(sfdob);
	}

	public void setPfemail(String sfemail) {
		pfemail.sendKeys(sfemail);
	}

	public void setPfaddress(String sfaddress) {
		pfaddress.sendKeys(sfaddress);
	}

	public void setPfcity(String sfcity) {
		Select drpCity = new Select(driver.findElement(By.name("City")));
		drpCity.selectByVisibleText(sfcity);
	}

	public void setPfphone(String sfphone) {
		pfphone.sendKeys(sfphone);
	}

	public void setPfhobbies() {
		List<WebElement>element=driver.findElements(By.name("chkHobbies"));
		for (WebElement pfhobbies : element) {
			
	pfhobbies.click();
	}
	}
	
	public void setPfsubmit() {
		pfsubmit.click();
	}
	
	//getters

	public WebElement getPfsubmit() {
		return pfsubmit;
	}	

	public WebElement getPfuname() {
		return pfuname;
	}

	public WebElement getPfpassword() {
		return pfpassword;
	}

	public WebElement getPfcpassword() {
		return pfcpassword;
	}

	public WebElement getPffirstname() {
		return pffirstname;
	}

	public WebElement getPflastname() {
		return pflastname;
	}

	public WebElement getPfgender() {
		return pfgender;
	}

	public WebElement getPfdob() {
		return pfdob;
	}

	public WebElement getPfemail() {
		return pfemail;
	}

	public WebElement getPfaddress() {
		return pfaddress;
	}

	public WebElement getPfcity() {
		return pfcity;
	}

	public WebElement getPfphone() {
		return pfphone;
	}

	public WebElement getPfhobbies() {
		return pfhobbies;
	}
	
}
