package com.cg.testRunner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="feature", glue="com.cg.registerStepDefs")
public class RunTestHotelBooking {

}
