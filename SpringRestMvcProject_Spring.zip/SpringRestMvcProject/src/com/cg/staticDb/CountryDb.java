package com.cg.staticDb;

import java.util.ArrayList;

import com.cg.bean.Country;

public class CountryDb{
	
	private static ArrayList<Country> countryList=new ArrayList<>();
	
	static {
		countryList.add(new Country("1001","India","3234567"));
		countryList.add(new Country("1002","Germany","64567"));
		countryList.add(new Country("1003","Srilanka","34567"));
		countryList.add(new Country("1004","China","454567"));
		countryList.add(new Country("1005","USA","134567"));		
	}

	public static ArrayList<Country> getCountryList() {
		return countryList;
	}

	public static void setCountryList(ArrayList<Country> countryList) {
		CountryDb.countryList = countryList;
	}
	
}
