package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.Login;
import com.cg.bean.Trainee;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {

	ArrayList<String> domainList = null;

	@Autowired
	TraineeService traineeService;

	public TraineeService getTraineeService() {
		return traineeService;
	}


	public void setTraineeService(TraineeService traineeService) {
		this.traineeService = traineeService;
	}


	@RequestMapping(value="/ShowLoginPage", method=RequestMethod.GET)
	public String displayLoginPage(Model model) {

		Login login = new Login();
		model.addAttribute("log", login);
		return "login";	
	}

	@RequestMapping(value="/validateUser", method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="log") 
	@Valid Login login, BindingResult result, Model model) {

		Login user = traineeService.validateUser(login);
		if(user!=null) {

			return "menu";
		}
		else {

			return "error"; 
		}		
	}

	/******************Show Add Trainee*******************/

	@RequestMapping(value="/addTrainee")
	public String dispAddPage(Model model) {

		domainList = new ArrayList<>();
		domainList.add("Analyst");
		domainList.add("Developer");
		domainList.add("Manager");
		domainList.add("Trainer");

		Trainee trainee = new Trainee();

		model.addAttribute("add", trainee);
		model.addAttribute("dmList", domainList);

		return "addTrainee";	
	}

	/**************Insert.obj***************/
	@RequestMapping(value="/InsertUser")
	public String addTrainee(@ModelAttribute(value="add") 
	@Valid Trainee trainee, BindingResult result, Model model) {

		if(result.hasErrors()) {	
			model.addAttribute("dmList", domainList);
			return "addTrainee";
		}
		else {
			traineeService.insertTraineeDetails(trainee);				
			return "result";	
		}	
	}

	/**************retrieveAllTrainess.obj***************/

	@RequestMapping(value="/retrieveAllTrainess")
	public String retrieveAllTrainess(@ModelAttribute(value="add")
	@Valid Trainee tr, BindingResult result, Model model) {

		ArrayList<Trainee> traineeList = traineeService.getTraineeDetails();//retrive data from array list
		model.addAttribute("traineeListObj", traineeList);
		return "retrieveAllTrainess";
	}

	/*****************DeleteUser.obj**************/

	@RequestMapping(value="/deleteTrainee", method = RequestMethod.GET)
	public String dispDeletePage( Model model) {
		model.addAttribute("delete", new Trainee());
		return "deleteTrainee";		
	}

	@RequestMapping(value="/DeleteTrainee", method=RequestMethod.POST)
	public String deleteTrainee(@ModelAttribute(value="delete")
	@Valid Trainee trainee, BindingResult result, Model model) {

		Trainee tr = traineeService.deleteTrainee(trainee.getTraineeId());
		if(tr!=null) {
			ArrayList<Trainee> traineeList = traineeService.getTraineeDetails();
			model.addAttribute("traineeListObj", traineeList);
			model.addAttribute("MsgObj", "data deleted");
			return "retrieveAllTrainess";
		}
		else {
			return "notDeleted";
		}		
	}

	/*****************RetrieveTrainee.obj**************/

	@RequestMapping(value="/retrieveTrainee", method=RequestMethod.GET)
	public String dispRetrieveTrainee(Model model) {
		model.addAttribute("retrieve", new Trainee());
		return "retrieveTrainee";	
	}

	@RequestMapping(value="/displayTrainee", method=RequestMethod.POST )
	public String retrieveTrainee(@ModelAttribute(value="retrieve")
	@Valid Trainee trainee, BindingResult result, Model model){

		Trainee tr = traineeService.getTraineeDetails(trainee.getTraineeId());
		model.addAttribute("trainee", tr);
		return "retrieveTrainee";
	}

	/*****************UpdateTrainee.obj**************/

	@RequestMapping(value="/modifyTrainee",method=RequestMethod.GET)
	public String displayUpdateTrainee(Model model) {
		domainList = new ArrayList<>();
		domainList.add("Analyst");
		domainList.add("Developer");
		domainList.add("Manager");
		domainList.add("Trainer");

		Trainee trainee = new Trainee();

		model.addAttribute("modify", trainee);
		model.addAttribute("dmList", domainList);

		return "modifyTrainee";
	}

	@RequestMapping(value="/updateTraineeDetails",method=RequestMethod.POST)
	public String updateUser(@ModelAttribute(value="modify") Trainee trainee,Model model) {
		Trainee rd=traineeService.updateTrainees(trainee);
		model.addAttribute("msg", rd);
		return  "updated";
	}	
}







