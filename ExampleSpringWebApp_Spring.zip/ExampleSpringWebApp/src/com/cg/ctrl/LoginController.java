package com.cg.ctrl;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("myCtrl")
public class LoginController {

	@RequestMapping(value="/LoginIn", method = RequestMethod.GET)
	public ModelAndView Login() {
		
		return new ModelAndView("LoginIn");
		//return new ModelAndView("LoginIn","tdObj",new LoginPage());//(view name,model obj name,model obj value)

	}
	/* @RequestMapping(value = "/addLoginPage", method = RequestMethod.POST)
     public String addLoginPage(@ModelAttribute("SpringWeb")LoginPage login, ModelMap model) {
     model.addAttribute("UserName", login.getUserName());
     model.addAttribute("Password", login.getPassword());
     
     return "result";
  }*/
}
