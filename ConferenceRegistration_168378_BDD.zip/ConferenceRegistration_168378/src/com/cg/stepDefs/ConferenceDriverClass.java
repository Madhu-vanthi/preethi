package com.cg.stepDefs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ConferenceDriverClass {

	static WebDriver driver;
	static String alertMessage;	

	public static void main(String[] args) {
		
		String driverPath = "D:\\Lesson 5-HTML Pages\\chromedriver_win32\\";
		
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		//driver = new FirefoxDriver();
		
		driver.get("file:///D:/Lesson%205-HTML%20Pages/Hotel/hotelbooking.html");

		String title=driver.getTitle();
		System.out.println("The page title is :" + title);

		//Empty first name
		driver.findElement(By.name("txtFN")).sendKeys("");
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();

		//Valid first name
		driver.findElement(By.name("txtFN")).sendKeys("Preethi");
		
		//empty last name
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("");
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();

		//valid last name
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Padmawar");


		//empty email
		driver.findElement(By.name("Email")).sendKeys("");
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();
		
		//invalid email
		driver.findElement(By.name("Email")).sendKeys("p.com");								
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();
		
		//valid email
		driver.findElement(By.name("Email")).clear();
		driver.findElement(By.name("Email")).sendKeys("neel.padmawar@gmail.com");	

		//empty contact number
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("");
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();
		
		//invalid contact number
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7896");	
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();
		
		//valid contact number
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).clear();
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7897897890");	
		
		//empty persons
		Select persons = new Select(driver.findElement(By.name("size")));
		persons.selectByVisibleText("");
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();
				
		//select persons
		persons.selectByVisibleText("2");
		
		//empty building name
		driver.findElement(By.id("txtAddress1")).sendKeys("");
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();
		
		//valid email
		driver.findElement(By.id("txtAddress1")).clear();
		driver.findElement(By.id("txtAddress1")).sendKeys("Manas Building room no.687");	
		
		//empty area name
		driver.findElement(By.id("txtAddress2")).sendKeys("");
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();

		//valid email
		driver.findElement(By.id("txtAddress2")).clear();
		driver.findElement(By.id("txtAddress2")).sendKeys("Mv Nagar");
		
		//empty city
		Select drpCity = new Select(driver.findElement(By.name("city")));
		drpCity.selectByVisibleText("Select City");
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();
		
		//select city
		drpCity.selectByVisibleText("Chennai");


		//empty sate
		Select drpState = new Select(driver.findElement(By.name("state")));
		drpState.selectByVisibleText("Select State");
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();
		
		//select state
		drpState.selectByVisibleText("Tamilnadu");
		
		//valid member status
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input")).click();
		
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();	
		callAlert();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.close();

	}
	
	public static void callAlert()
	{
		String alertMessage= driver.switchTo().alert().getText();
		System.out.println(alertMessage);		
		driver.switchTo().alert().accept();

	}
}
