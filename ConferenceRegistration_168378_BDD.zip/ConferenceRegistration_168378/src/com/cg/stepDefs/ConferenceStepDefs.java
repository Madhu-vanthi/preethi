package com.cg.stepDefs;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import comc.g.pageBean.ConferencePageFactory;
import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferenceStepDefs {
	
	private WebDriver driver;
	private ConferencePageFactory cpg= new ConferencePageFactory(driver);
	
	@Before
	public void openBrowser() {
		
		String driverPath = "D:\\Lesson 5-HTML Pages\\chromedriver_win32\\";		
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		
		cpg = new ConferencePageFactory(driver);		
		driver.get("file:///D:/Web%20Pages%20Conference%20Registration/ConferenceRegistartion.html");
	}

	@Given("^User is on the conference registration page$")
	public void user_is_on_the_conference_registration_page() throws Throwable {
		
		cpg = new ConferencePageFactory(driver);		
		driver.get("file:///D:/Web%20Pages%20Conference%20Registration/ConferenceRegistartion.html");}
	@Then("^Check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	    
		String title = driver.getTitle();
		if(title.contentEquals("Conference Registartion")) System.out.println("****Title matched****");
		else System.out.println("****Title mismatch****");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^User does not enter first name$")
	public void user_does_not_enter_first_name() throws Throwable {
	    
		cpg.setFirstName("");	Thread.sleep(500);
	}

	@When("^Clicks the button$")
	public void clicks_the_button() throws Throwable {
	   
		cpg.setButton();
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
	    
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(500);
		System.out.println(alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User does not enter last name$")
	public void user_does_not_enter_last_name() throws Throwable {
	    
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("");	Thread.sleep(500);
	}

	@When("^User does not enter email$")
	public void user_does_not_enter_email() throws Throwable {
	    
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("Varsha");	Thread.sleep(500);
		cpg.setEmail("");	Thread.sleep(500);
	}

	@When("^User does not enter contact number$")
	public void user_does_not_enter_contact_number() throws Throwable {
	   
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("Varsha");	Thread.sleep(500);
		cpg.setEmail("preevarsha@gmail.com");	Thread.sleep(500);
		cpg.setContactNo("");	Thread.sleep(500);
	}

	@When("^User enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
	  
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("Varsha");	Thread.sleep(500);
		cpg.setEmail("preevarsha@gmail.com");	Thread.sleep(500);
		List<String> mobList = arg1.asList(String.class);
		cpg.setButton();	
		
		for(int i=0; i<mobList.size(); i++) {
			
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$", mobList.get(i))) {
			System.out.println("***** Matched" + mobList.get(i) + "*****");
			}
			else {
				System.out.println("***** NOT Matched" + mobList.get(i) + "*****");
			}
		}
	}

	@When("^User does not select the no\\.of people attending$")
	public void user_does_not_select_the_no_of_people_attending() throws Throwable {
	   
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("Varsha");	Thread.sleep(500);
		cpg.setEmail("preevarsha@gmail.com");	Thread.sleep(500);
		cpg.setContactNo("9999999999");	Thread.sleep(500);
		cpg.setNoOfpeople("");	Thread.sleep(500);
	}

	@When("^User does not enter building name & room number$")
	public void user_does_not_enter_building_name_room_number() throws Throwable {
	   
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("Varsha");	Thread.sleep(500);
		cpg.setEmail("preevarsha@gmail.com");	Thread.sleep(500);
		cpg.setContactNo("9999999999");	Thread.sleep(500);
		cpg.setNoOfpeople("2");	Thread.sleep(500);
		cpg.setBldngNameNRoomNo("");	Thread.sleep(500);
	}

	@When("^User does not enter area name$")
	public void user_does_not_enter_area_name() throws Throwable {
	  
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("Varsha");	Thread.sleep(500);
		cpg.setEmail("preevarsha@gmail.com");	Thread.sleep(500);
		cpg.setContactNo("9999999999");	Thread.sleep(500);
		cpg.setNoOfpeople("2");	Thread.sleep(500);
		cpg.setBldngNameNRoomNo("Manas Building and Room No.402");	Thread.sleep(500);
		cpg.setAreaName("");	Thread.sleep(500);
	}

	@When("^User does not select city$")
	public void user_does_not_select_city() throws Throwable {
	    
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("Varsha");	Thread.sleep(500);
		cpg.setEmail("preevarsha@gmail.com");	Thread.sleep(500);
		cpg.setContactNo("9999999999");	Thread.sleep(500);
		cpg.setNoOfpeople("2");	Thread.sleep(500);
		cpg.setBldngNameNRoomNo("Manas Building, Room No.402");	Thread.sleep(500);
		cpg.setAreaName("MV Nagar");	Thread.sleep(500);	
		cpg.setCity("Select City");	Thread.sleep(500);
	}

	@When("^User does not select state$")
	public void user_does_not_select_state() throws Throwable {
	    
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("Varsha");	Thread.sleep(500);
		cpg.setEmail("preevarsha@gmail.com");	Thread.sleep(500);
		cpg.setContactNo("9999999999");	Thread.sleep(500);
		cpg.setNoOfpeople("2");	Thread.sleep(500);
		cpg.setBldngNameNRoomNo("Manas Building, Room No.402");	Thread.sleep(500);
		cpg.setAreaName("MV Nagar");	Thread.sleep(500);	
		cpg.setCity("Chennai");	Thread.sleep(500);
		cpg.setState("Select State");	Thread.sleep(500);
	}

	@When("^User does not select either conference full access\\(member\\) or conference full access\\(non-member\\)$")
	public void user_does_not_select_either_conference_full_access_member_or_conference_full_access_non_member() throws Throwable {
	  
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("Varsha");	Thread.sleep(500);
		cpg.setEmail("preevarsha@gmail.com");	Thread.sleep(500);
		cpg.setContactNo("9999999999");	Thread.sleep(500);
		cpg.setNoOfpeople("2");	Thread.sleep(500);
		cpg.setBldngNameNRoomNo("Manas Building, Room No.402");	Thread.sleep(500);
		cpg.setAreaName("MV Nagar");	Thread.sleep(500);	
		cpg.setCity("Chennai");	Thread.sleep(500);
		cpg.setState("Tamilnadu");	Thread.sleep(500);
	}
	
	@When("^User enters all valid details$")
	public void user_enters_all_valid_details() throws Throwable {
	    
		cpg.setFirstName("Preethi");	Thread.sleep(500);
		cpg.setLastName("Varsha");	Thread.sleep(500);
		cpg.setEmail("preevarsha@gmail.com");	Thread.sleep(500);
		cpg.setContactNo("9999999999");	Thread.sleep(500);
		cpg.setNoOfpeople("2");	Thread.sleep(500);
		cpg.setBldngNameNRoomNo("Manas Building, Room No.402");	Thread.sleep(500);
		cpg.setAreaName("MV Nagar");	Thread.sleep(500);	
		cpg.setCity("Chennai");	Thread.sleep(500);
		cpg.setState("Tamilnadu");	Thread.sleep(500);
		cpg.setMember();  Thread.sleep(500);
	}

	@Then("^display alert message and navigate to payment details$")
	public void display_alert_message_and_navigate_to_payment_details() throws Throwable {
	    
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(500);
		System.out.println(alertMessage);
		driver.switchTo().alert().accept();
		
		driver.navigate().to("file:///D:/Web%20Pages%20Conference%20Registration/PaymentDetails.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@After
	public void closeBrowser() {
		
		driver.close();
	}
}
