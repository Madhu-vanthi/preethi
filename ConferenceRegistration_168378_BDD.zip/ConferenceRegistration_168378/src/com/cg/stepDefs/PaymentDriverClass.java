package com.cg.stepDefs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PaymentDriverClass {

	static WebDriver driver;
	static String alertMessage;	

	public static void main(String[] args) {
		
		String driverPath = "D:\\Lesson 5-HTML Pages\\chromedriver_win32\\";
		
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();	
		
		driver.get("file:///D:/Web%20Pages%20Conference%20Registration/PaymentDetails.html");

		String title=driver.getTitle();
		System.out.println("The page title is :" + title);

		//empty card holder name
		driver.findElement(By.id("txtCardholderName")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();	
		callAlert();
		
		//valid card holder name
		driver.findElement(By.id("txtCardholderName")).sendKeys("Preethi Varsha");

		//empty card number
		driver.findElement(By.id("txtDebit")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();	
		callAlert();
		
		//valid card number
		driver.findElement(By.id("txtDebit")).sendKeys("8454215756541354");

		//empty cvv
		driver.findElement(By.name("cvv")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();	
		callAlert();
		
		//valid cvv
		driver.findElement(By.name("cvv")).sendKeys("564");

		//empty month
		driver.findElement(By.id("txtMonth")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();	
		callAlert();
		
		//valid month
		driver.findElement(By.id("txtMonth")).sendKeys("March");

		//empty year
		driver.findElement(By.id("txtYear")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();	
		callAlert();
		
		//valid year
		driver.findElement(By.id("txtYear")).sendKeys("2023");

		
		driver.findElement(By.id("btnPayment")).click();
		callAlert();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.close();


	}
	
	public static void callAlert()
	{
		String alertMessage= driver.switchTo().alert().getText();
		System.out.println(alertMessage);		
		driver.switchTo().alert().accept();

	}
}
