package com.cg.stepDefs;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import comc.g.pageBean.PersonalDetailsPageFactory;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalDetailsStepDefs {

	private WebDriver driver;
	private PersonalDetailsPageFactory pdpf= new PersonalDetailsPageFactory(driver);
	
	@Before
	public void openBrowser() {
		
		String driverPath = "D:\\Lesson 5-HTML Pages\\chromedriver_win32\\";		
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();		
		
		pdpf = new PersonalDetailsPageFactory(driver);		
		driver.get("file:///D:/Web%20Pages%20Conference%20Registration/PaymentDetails.html");
	}
	
	@Given("^User is on the payment details page$")
	public void user_is_on_the_payment_details_page() throws Throwable {
	   
		pdpf = new PersonalDetailsPageFactory(driver);		
		driver.get("file:///D:/Web%20Pages%20Conference%20Registration/PaymentDetails.html");
	}	
	
	@Then("^Check whether the title of the page matches or not$")
	public void check_whether_the_title_of_the_page_matches_or_not() throws Throwable {
	   
		String title = driver.getTitle();
		if(title.contentEquals("Payment Details")) System.out.println("****Title matched****");
		else System.out.println("****Title mismatch****");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}


	@When("^User does not enter card holder name and clicks the button$")
	public void user_does_not_enter_card_holder_name_and_clicks_the_button() throws Throwable {
		
		pdpf.setCardHolderName("");			Thread.sleep(500);
   		pdpf.setMakePayment();
	}
	
	@Then("^print alert message$")
	public void print_alert_message() throws Throwable {
		
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(500);
		System.out.println(alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User does not enter debit card number and clicks the button$")
	public void user_does_not_enter_debit_card_number_and_clicks_the_button() throws Throwable {
   
		pdpf.setCardHolderName("Preethi");			Thread.sleep(500);
		pdpf.setDebitCardNo("");			Thread.sleep(500);
		pdpf.setMakePayment();
	}

	@When("^User does not enter cvv and clicks the button$")
	public void user_does_not_enter_cvv_and_clicks_the_button() throws Throwable {
    
		pdpf.setCardHolderName("Preethi");			Thread.sleep(500);
		pdpf.setDebitCardNo("354564612246");			Thread.sleep(500);
		pdpf.setCvv("");			Thread.sleep(500);
		pdpf.setMakePayment();
	}

	@When("^User does not enter month and clicks the button$")
	public void user_does_not_enter_month_and_clicks_the_button() throws Throwable {
   
		pdpf.setCardHolderName("Preethi");			Thread.sleep(500);
		pdpf.setDebitCardNo("354564612246");			Thread.sleep(500);
		pdpf.setCvv("456");			Thread.sleep(500);
		pdpf.setMonth("");			Thread.sleep(500);
		pdpf.setMakePayment();
	}

	@When("^User does not enter year and clicks the button$")
	public void user_does_not_enter_year_and_clicks_the_button() throws Throwable {
    
		pdpf.setCardHolderName("Preethi");			Thread.sleep(500);
		pdpf.setDebitCardNo("354564612246");			Thread.sleep(500);
		pdpf.setCvv("456");			Thread.sleep(500);
		pdpf.setMonth("March");			Thread.sleep(500);
		pdpf.setYear("");			Thread.sleep(500);
		pdpf.setMakePayment();
	}

   @When("^User enters all valid credentials and clicks the button$")
   public void user_enters_all_valid_credentials_and_clicks_the_button() throws Throwable {
   
	   pdpf.setCardHolderName("Preethi");			Thread.sleep(500);
	   pdpf.setDebitCardNo("354564612246");				Thread.sleep(500);
	   pdpf.setCvv("456");			Thread.sleep(500);
	   pdpf.setMonth("March");			Thread.sleep(500);
	   pdpf.setYear("2023");			Thread.sleep(500);
	   pdpf.setMakePayment();			Thread.sleep(500);
	}


	@After
	public void closeBrowser() {
		
		driver.close();
	}

}
