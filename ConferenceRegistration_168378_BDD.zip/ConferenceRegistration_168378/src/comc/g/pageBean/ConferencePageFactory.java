package comc.g.pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferencePageFactory {

	WebDriver driver;

	public ConferencePageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//step 1 : Identifying the elements
		
		//using id
		@FindBy(id="txtFirstName")
		@CacheLookup
		WebElement firstName;
		
		//using how class
		@FindBy(how=How.ID, using="txtLastName")
		@CacheLookup
		WebElement lastName;		
		
		@FindBy(xpath=".//*[@id='txtEmail']")
		@CacheLookup
		WebElement email;
		
		@FindBy(css="input[pattern=\"[789][0-9]{9}\"]")
		@CacheLookup
		WebElement contactNo;
		
		@FindBy(how=How.NAME, using="size")
		@CacheLookup
		WebElement noOfpeople;
		
		@FindBy(how=How.ID, using="txtAddress1")
		@CacheLookup
		WebElement bldngNameNRoomNo;	
		
		@FindBy(xpath=".//*[@id='txtAddress2']")
		@CacheLookup
		WebElement areaName;	
		
		@FindBy(how=How.NAME, using="city")
		@CacheLookup
		WebElement city;
		
		@FindBy(how=How.NAME, using="state")
		@CacheLookup
		WebElement state;
		
		@FindBy(xpath="html/body/form/table/tbody/tr[12]/td[2]/input")
		@CacheLookup
		WebElement member;	
		
		@FindBy(xpath="html/body/form/table/tbody/tr[13]/td[2]/input")
		@CacheLookup
		WebElement nonMember;	
		
		@FindBy(xpath="html/body/form/table/tbody/tr[14]/td/a")
		@CacheLookup
		WebElement button;
		
	//step 2 : Getters and Setters

		public WebElement getFirstName() {
			return firstName;
		}

		public void setFirstName(String fName) {
			firstName.sendKeys(fName);
		}

		public WebElement getLastName() {
			return lastName;
		}

		public void setLastName(String lName) {
			lastName.sendKeys(lName);
		}

		public WebElement getEmail() {
			return email;
		}

		public void setEmail(String emailId) {
			email.sendKeys(emailId);
		}

		public WebElement getContactNo() {
			return contactNo;
		}

		public void setContactNo(String cntctNo) {
			contactNo.sendKeys(cntctNo);
		}		

		public WebElement getNoOfpeople() {
			return noOfpeople;
		}

		public void setNoOfpeople(String persons) {
			noOfpeople.sendKeys(persons);
		}

		public WebElement getBldngNameNRoomNo() {
			return bldngNameNRoomNo;
		}

		public void setBldngNameNRoomNo(String bldngNRoom) {
			bldngNameNRoomNo.sendKeys(bldngNRoom);
		}

		public WebElement getAreaName() {
			return areaName;
		}

		public void setAreaName(String area) {
			areaName.sendKeys(area);
		}

		public WebElement getCity() {
			return city;
		}

		public void setCity(String cityName) {
			Select drpCity = new Select(city);
			drpCity.selectByVisibleText(cityName);
		}

		public WebElement getState() {
			return state;
		}

		public void setState(String stateName) {
			Select drpCity = new Select(state);
			drpCity.selectByVisibleText(stateName);
		}

		public WebElement getButton() {
			return button;
		}

		public void setButton() {
			button.click();
		}

		public WebElement getMember() {
			return member;
		}

		public void setMember() {
			member.click();
		}

		public WebElement getNonMember() {
			return nonMember;
		}

		public void setNonMember() {
			nonMember.click();
		}

		
}
