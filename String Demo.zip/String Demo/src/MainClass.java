import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		StringClass str = new StringClass("Madhesh");
		Scanner s = new Scanner(System.in);
		String str1 = s.nextLine();
		
		System.out.println(str);
	}
	
		
		
		
		
	
	

}
