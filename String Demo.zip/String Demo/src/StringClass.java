import java.util.Scanner;

public class StringClass {
	
	private String name;
	public StringClass() {}
	public String getName() {
		return name;
	}
	public StringClass(String name) {
		super();
		this.name = name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public static void Operations(String str) {		
		Scanner s = new Scanner(System.in);
		System.out.println("Enter some number: ");
		int num = s.nextInt();
		switch(num) {
		case 1: str = str+"Sr";
					break;
		case 2: for(int i=0;i<str.length();i++)
			if(i%2 !=0) str = "#";
		 			break;
		case 3: for(int i=0;i<str.length();i++) {
			char a[] = (char)str;
		}
			
			
			break;
		case 4: for(int i=0;i<str.length();i++)
			if(i%2 !=0) str.toUpperCase();
					break;
			
		}
	}
}
