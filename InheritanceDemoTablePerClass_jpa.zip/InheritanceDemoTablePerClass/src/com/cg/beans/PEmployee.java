package com.cg.beans;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
public class PEmployee extends Employee{

	private int hra,ta,da;
	public PEmployee() {
		super();}
	
	public PEmployee(int employeeId, String firstName, String lastName) {
		super(employeeId, firstName, lastName);
		
	}
	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getTa() {
		return ta;
	}
	public void setTa(int ta) {
		this.ta = ta;
	}
	public int getDa() {
		return da;
	}
	public void setDa(int da) {
		this.da = da;
	}
	@Override
	public String toString() {
		return super.toString() +",hra=" + hra + ", ta=" + ta + ", da=" + da ;
	}
}
