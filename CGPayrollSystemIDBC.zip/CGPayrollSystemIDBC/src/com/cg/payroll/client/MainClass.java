package com.cg.payroll.client;

import com.cg.payroll.Services.PayrollServicesImpl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.payroll.Services.PayrollServices;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.util.DBUtil;

public class MainClass {

	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, IOException, SQLException{
		
		/*Associate[] associates=new Associate[5];		
		associates[0]=new Associate(213,968686,"preethi","sr","tester","testing team","pree@gmail.com",new Salary(25000,2000,3000),new Banking(1234,"HDFC","HDFC8677"));
		associates[1]=new Associate(645,658746,"gopika","ankani","developer","developing team","gopi@gmail.com",new Salary(30000,2500,4000),new Banking(2345,"ANDB","ANDB9868"));
		associates[2]=new Associate(436,764647,"aanchal","srivatsa","coder","developing team","aanchal@gmail.com",new Salary(40000,3000,4500),new Banking(3456,"HDFC","HDFC7686"));
		associates[3]=new Associate(646,575557,"madhu","vanthi","tester","testing team","madhu@gmail.com",new Salary(50000,6500,5000),new Banking(4567,"STB","STB8989"));
		associates[4]=new Associate(546,528752,"lakshmi","manchu","analyst","training team","manchu@gmail.com",new Salary(10000,4000,1500),new Banking(5678,"ANDB","ANDB6447"));
		for (Associate associate : associates)			
			if(associate.getSalary().getBasicSalary()>=20000 && associate.getBanking().getBankName()=="HDFC") {
				System.out.println(associate.getFirstName()+"\t"+associate.getLastName());
			}*/
		/*try {
			
			PayrollServices payrollServices =new PayrollServicesImpl();		
			int associateId = payrollServices.acceptAssociateDetails(5000, "madhu", "vanthi", "tester", "testing team", "madhu@gmail.com",
									25000, 2500, 3000,231442, "HDFC", "HDFC5356");
			associateId = payrollServices.acceptAssociateDetails(658746,"gopika","ankani","developer","developing team","gopi@gmail.com",
									30000,2500,4000,2345,"ANDB","ANDB9868");
			associateId = payrollServices.acceptAssociateDetails(968686,"preethi","sr","tester","testing team","pree@gmail.com",
									25000,2000,3000,1234,"HDFC","HDFC8677");
			associateId = payrollServices.acceptAssociateDetails(764647,"aanchal","srivatsa","coder","developing team","aanchal@gmail.com",
									40000,3000,4500,3456,"HDFC","HDFC7686");
			System.out.println("Associate ID:"+associateId);
			Scanner input = new Scanner(System.in);
			int num = 0;
			boolean value = true;
			while(value) {
				System.out.println("enter number of method which you want to implement:");
				num = input.nextInt();
				switch(num) {
				case 1:
					System.out.println(payrollServices.calculateNetSalary(input.nextInt()));
					break;
				case 2:
					System.out.println(payrollServices.getAssociateDetails(input.nextInt()));
					break;
				case 3:
					System.out.println(payrollServices.getAllAssociateDetails());
					break;
				default:
					System.out.println("you entered default case");
					value = false;
					break;				
						
				}
			}			
			
		} catch ( AssociateDetailsNotFoundException e ) {
			
			e.printStackTrace();
		}	*/
		
		
	}
}
