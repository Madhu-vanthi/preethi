package com.cg.payroll.util;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	private static Connection con;
	public static Connection getDBConnection() {
			try{
				if(con==null) {
				Properties dbProperties = new Properties();
				dbProperties.load(new FileInputStream(new File(".//resources//payroll.properties")));
				String driver = dbProperties.getProperty("driver");
				String url = dbProperties.getProperty("url");
				String user = dbProperties.getProperty("user");
				String password = dbProperties.getProperty("password");
				Class.forName(driver);
				con= DriverManager.getConnection(url, user, password);			
				}
			} catch (ClassNotFoundException | IOException | SQLException e) {			
				e.printStackTrace();
			}
			return con;
	}

}
