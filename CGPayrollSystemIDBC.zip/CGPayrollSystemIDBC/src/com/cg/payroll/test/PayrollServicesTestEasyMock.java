package com.cg.payroll.test;

import java.util.ArrayList;


import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.Services.PayrollServices;
import com.cg.payroll.Services.PayrollServicesImpl;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Banking;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;


public class PayrollServicesTestEasyMock {
	
	/*private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDAO;
	
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDAO = EasyMock.mock(AssociateDAO.class);
		payrollServices = new PayrollServicesImpl(mockAssociateDAO);
	}
	
	@Before
	public void setUpTestMockData() {
		Associate associate1 = new Associate(101,5000, "madhu", "vanthi", "tester", "testing team", "madhu@gmail.com",
				new Salary( 25000, 2500, 3000),new Banking(231442, "HDFC", "HDFC5356"));
		Associate associate2 = new Associate(102,87317,"gopi","ankani","training","manager","gopi@gmail.com",
				new Salary(25000,1800,1800),new Banking(54321,"HDFC","HDFC1234"));
		Associate associate3 = new Associate(65440,"lakshmi","manchu","ADC","trainee","manchu@gmail.com",
				new Salary(48000,1800,1800),new Banking(123738,"HDFC","HDFC1234"));
		
		ArrayList<Associate> associatesList = new ArrayList<>();
		associatesList.add(associate1);
		associatesList.add(associate2);
		
		EasyMock.expect(mockAssociateDAO.save(associate3)).andReturn(associate3);
		
		EasyMock.expect(mockAssociateDAO.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDAO.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDAO.findOne(1023)).andReturn(null);
		EasyMock.expect(mockAssociateDAO.findAll()).andReturn(associatesList);
	
	}
	
	@Test(expected = AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId()throws AssociateDetailsNotFoundException{
		
		payrollServices.getAssociateDetails(1023);
		EasyMock.verify(mockAssociateDAO.findOne(1023));
		
	}
	
	@Test
	public void testGetAssociateDataForValidAssociateId()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate = new Associate(101, 5000, "madhu", "vanthi", "tester", "testing team", "madhu@gmail.com",
				new Salary( 25000, 2500, 3000),new Banking(231442, "HDFC", "HDFC5356"));
		Associate actualAssociate = mockAssociateDAO.findOne(101);		
		Assert.assertEquals(expectedAssociate, actualAssociate);
		EasyMock.verify(mockAssociateDAO.findOne(101));
		
	}
	
	@Test(expected = AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId()throws AssociateDetailsNotFoundException {
		payrollServices.getAssociateDetails(250);
		EasyMock.verify(mockAssociateDAO.findOne(123));
		
	}
	
	@Test
	public void testCalculateNetSalaryForValidAssociateId()throws AssociateDetailsNotFoundException {
		int expectedNetSalary = 21950;
		int actualNetSalary = payrollServices.calculateNetSalary(101);
		EasyMock.verify(mockAssociateDAO.findOne(101));
		Assert.assertEquals(expectedNetSalary,actualNetSalary);
		
	}
	
	@Test
	public void testForGetAllAssociateDetails() {
		 ArrayList<Associate> expectedAssociateList=new ArrayList<>(PayrollUtil.associates.values());
	     ArrayList<Associate> actualAssociateList=(ArrayList<Associate>) payrollServices.getAllAssociateDetails();
	     Assert.assertEquals(expectedAssociateList, actualAssociateList);
	     EasyMock.verify(mockAssociateDAO.findAll());
	     
	}
	
	@After
	public void tearDownTestData() {		
		EasyMock.resetToDefault(mockAssociateDAO);
		
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDAO = null;
		payrollServices = null;
		
	}*/
}
	


