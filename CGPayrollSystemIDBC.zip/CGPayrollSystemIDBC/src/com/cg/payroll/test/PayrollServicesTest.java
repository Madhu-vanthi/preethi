package com.cg.payroll.test;

import java.util.ArrayList;



import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.Services.PayrollServicesImpl;
import com.cg.payroll.Services.PayrollServices;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Banking;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;


public class PayrollServicesTest {

	/*static PayrollServices payrollServices;
	@BeforeClass
	public static void setUpTestEnv() {
		payrollServices = new PayrollServicesImpl();		
	}
	@Before
	public void setUpTestData() {
		Associate associate1 = new Associate(101,5000, "madhu", "vanthi", "tester", "testing team", "madhu@gmail.com",
				new Salary( 25000, 2500, 3000),new Banking(231442, "HDFC", "HDFC5356"));
		Associate associate2 = new Associate(102,8282,"gopi","ankani","training","manager",
				"gopi@gmail.com",new Salary(32000,1800,1800),new Banking(15312,"HDFC","HDFC7451"));
		PayrollUtil.associates.put(associate1.getAssociateID(),associate1);
		PayrollUtil.associates.put(associate2.getAssociateID(),associate2);
		PayrollUtil.ASSOCIATE_ID_COUNTER = 102;
	
	}
	@Test
	public void testAcceptAssociateDetailsForValidData() {
		int expectedAssociateId = 103;
		int actualAssocaiteId = payrollServices.acceptAssociateDetails(32000,"lakshmi","manchu","lakshmi@gmail.com",
				"ADM","Manager",30000,1800,1800,64545,"ICICI","ICICI8473");
		Assert.assertEquals(expectedAssociateId, actualAssocaiteId);
		
	}
	@Test(expected = AssociateDetailsNotFoundException.class)
		public void testGetAssociateDataForInvalidAssociateId()throws AssociateDetailsNotFoundException{
			payrollServices.getAssociateDetails(12121);
			
		}
	@Test
	public void testGetAssociateDataForValidAssociateId()throws AssociateDetailsNotFoundException{			
		Associate expectedAssociate=new Associate(101,5000, "madhu", "vanthi", "tester", "testing team", "madhu@gmail.com",
				new Salary( 25000, 2500, 3000),new Banking(231442, "HDFC", "HDFC5356"));
		Associate actualAssociate=payrollServices.getAssociateDetails(101);
		Assert.assertEquals(expectedAssociate,actualAssociate);
		}
	
	@Test
    public void testCalcualteNetSalaryForValidAssociateId()throws AssociateDetailsNotFoundException{
        int expectedNetSalary=21950;
        int actualNetSalary=payrollServices.calculateNetSalary(101);
        Assert.assertEquals(expectedNetSalary, actualNetSalary);
    }
    @Test
    public void testForGetAllAssociateDetails() {
        ArrayList<Associate> expectedAssociateList=new ArrayList<>(PayrollUtil.associates.values());
        ArrayList<Associate> actualAssociateList=(ArrayList<Associate>) payrollServices.getAllAssociateDetails();
        Assert.assertEquals(expectedAssociateList, actualAssociateList);
    }
    @After
	public void tearDownTestData() {
		PayrollUtil.ASSOCIATE_ID_COUNTER=100;
		PayrollUtil.associates.clear();
	}
	@AfterClass
	public static void tearDownTestEnv() {
		payrollServices=null;
	}	
		*/
}


