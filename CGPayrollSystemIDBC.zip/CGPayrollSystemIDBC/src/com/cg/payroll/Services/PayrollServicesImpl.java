package com.cg.payroll.Services;

import java.io.File;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;

public class PayrollServicesImpl implements PayrollServices{

	private AssociateDAO associateDAO;
	public PayrollServicesImpl() {
		associateDAO = new AssociateDAOImpl();
	}
	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}
	@Override
	public int acceptAssociateDetails( int yearlyInvestmentUnder80C, String firstName, String lastName,
			String designation, String department, String emailID,int basicSalary,
			int epf,int companyPf,int accountNumber,String bankName,String ifscCode) {

		Associate associate = new Associate( yearlyInvestmentUnder80C, firstName, lastName,
				designation, department, emailID, new Salary( basicSalary, epf, companyPf), new Banking(accountNumber, bankName, ifscCode));

		try {
			associate = associateDAO.save(associate);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return associate.getAssociateID();
	}

	@Override
	public int calculateNetSalary(int associateID) throws AssociateDetailsNotFoundException {

		Associate associate=this.getAssociateDetails(101);
		associate.getSalary().setHra((40/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setConveyenceAllowance((30/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setPersonalAllowance((20/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setOtherAllowance((20/100)*associate.getSalary().getBasicSalary());

		associate.getSalary().setGrossSalary((associate.getSalary().getBasicSalary()+associate.getSalary().getCompanyPf()+
				associate.getSalary().getConveyenceAllowance()+associate.getSalary().getEpf()+
				associate.getSalary().getHra()+associate.getSalary().getOtherAllowance()+
				associate.getSalary().getPersonalAllowance())*12);

		int taxable=associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()-
				associate.getSalary().getCompanyPf()*12-associate.getSalary().getEpf()*12;

		if(taxable>0 && taxable <=250000) 
			associate.getSalary().setMonthlyTax(0);		
		else if(taxable>250000 && taxable<=500000)
			associate.getSalary().setMonthlyTax((associate.getSalary().getGrossSalary()/12)/10);
		else if(taxable>500000 && taxable<=1000000)
			associate.getSalary().setMonthlyTax((((associate.getSalary().getGrossSalary()/12)/10)*2)+30000);	
		else
			associate.getSalary().setMonthlyTax((((associate.getSalary().getGrossSalary()/12)/10)*3)+130000);

		associate.getSalary().setNetSalary((associate.getSalary().getGrossSalary()/12)-
				associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-
				associate.getSalary().getMonthlyTax());

		return associate.getSalary().getNetSalary();

	}

	@Override
	public Associate getAssociateDetails(int associateID) throws AssociateDetailsNotFoundException {

		Associate associate = null;
		try {
			associate = associateDAO.findOne(associateID);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate details not found for associate Id:"+associateID);
		return associate;
	}

	@Override
	public List<Associate> getAllAssociateDetails() {

		try {
			return associateDAO.findAll();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}
	
	
	
}
