package com.cg.payroll.Services;

import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;

public interface PayrollServices {
	
	int acceptAssociateDetails( int yearlyInvestmentUnder80C, String firstName, String lastName,
			String designation, String department, String emailID,  int basicSalary, int personalAllowance, 
			int companyPf, int accountNumber, String bankName, String ifscCode);
	
	int calculateNetSalary(int associateID)throws AssociateDetailsNotFoundException;
	
	Associate getAssociateDetails(int associateID)throws AssociateDetailsNotFoundException;
	
	List<Associate> getAllAssociateDetails();
	

}
