package com.cg.DaoServices;

import java.awt.List;

import com.cg.beans.Customer;

public interface DaoServices {
	
	public Customer save(Customer customer);
	public boolean update(Customer customer);
	public Customer findOne(String cutomerNo) ;
	public List findAll();

}
