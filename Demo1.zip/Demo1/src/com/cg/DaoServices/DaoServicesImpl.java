package com.cg.DaoServices;

import java.awt.List;

import com.cg.Util.ElectricityBillUtil;
import com.cg.beans.Customer;

public class DaoServicesImpl implements DaoServices{

	@Override
	public Customer save(Customer customer) {
		
		customer.setCustomerNo(ElectricityBillUtil.getCUSTOMER_ID_COUNTER());
		ElectricityBillUtil.customers.put(customer.getCustomerNo(), customer);
		return customer;
	}

	@Override
	public boolean update(Customer customer) {
		
		ElectricityBillUtil.customers.put(customer.getCustomerNo(), customer);
		return true;
	}

	@Override
	public Customer findOne(String cutomerNo) {
		
		return ElectricityBillUtil.customers.get(cutomerNo);
	}

	@Override
	public List findAll() {
		
		return null;
	}
	
	

}
