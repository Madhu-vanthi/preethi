package com.cg.client;

import com.cg.beans.Address;
import com.cg.beans.Bill;
import com.cg.beans.Customer;
import com.cg.beans.Meter;

public class MainClass {

	public static void main(String[] args) {
		
		Customer[] customers = new Customer[3];
		
		 customers[0] = new Customer( "preethi", "varsha", "CGHF56732",	 new Address (65, 602220, 
				 "vaiagai st", "TN"), new Meter ( 6445, 200, 3, 54254, new Bill("5354", "544")));
		
	}

}
