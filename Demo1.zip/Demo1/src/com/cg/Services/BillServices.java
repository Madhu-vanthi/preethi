package com.cg.Services;

import java.util.ArrayList;
import java.util.List;

import com.cg.Exception.CustomerDetailsNotFoundException;
import com.cg.beans.Address;
import com.cg.beans.Customer;
import com.cg.beans.Meter;

public interface BillServices {	

	int acceptCustomerDetails(int customerNo, String firstName, String lastname, String mobileNo, 
			 String pancard,	String emailId,int doorNo, int pincode, String streetName, String state, 
			 int meterNo, int consumptionUnits, int phase, int meterLoad,String billNo, String billUnit);
	
	int acceptCustomerDetails(int c, String fName, String lname, String mobNo, 
			 String pancard,	String emailId, Address address, Meter meter);
	
	double calculateBill(int customerNo) throws CustomerDetailsNotFoundException;
	
	Customer getCustomerDetails(int customerNo) throws CustomerDetailsNotFoundException;
	
	List<Customer> getAllCustomerDetails();
	
	ArrayList<Customer> getAllCustomerDetails();

}
