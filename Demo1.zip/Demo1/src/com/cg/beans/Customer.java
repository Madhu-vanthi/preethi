package com.cg.beans;

public class Customer {
	
	private String firstName,lastname,mobileNo,pancard,emailId;
	private int customerNo;
	private Address address;
	private Meter meter;
	public Customer(){}
	public Customer(int customerNo, String firstName, String lastname, String mobileNo, 
			 String pancard,	String emailId, Address address, Meter meter) {
		super();
		this.customerNo = customerNo;
		this.firstName = firstName;
		this.lastname = lastname;
		this.mobileNo = mobileNo;
		this.pancard = pancard;
		this.emailId = emailId;
		this.address = address;
		this.meter = meter;
	}
	public Customer(int customerNo, String firstName, String lastname, String mobileNo, 
			String pancard,	String emailId) {
		super();
		this.customerNo = customerNo;
		this.firstName = firstName;
		this.lastname = lastname;
		this.mobileNo = mobileNo;
		this.pancard = pancard;
		this.emailId = emailId;
	}
	public Customer(String firstName, String lastname, String pancard, Address address, Meter meter) {
		super();
		this.firstName = firstName;
		this.lastname = lastname;
		this.pancard = pancard;
		this.address = address;
		this.meter = meter;
	}
	public int getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(int customerNo) {
		this.customerNo = customerNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Meter getMeter() {
		return meter;
	}
	public void setMeter(Meter meter) {
		this.meter = meter;
	}
	
	@Override
	public String toString() {
		return "Customer [customerNo=" + customerNo + ", firstName=" + firstName + ", lastname=" + 
				 lastname	+ ", mobileNo=" + mobileNo + ", pancard=" + pancard + ", emailId=" + emailId + 
				 ", address=" + getAddress().toString() + ", meter=" + getMeter().toString() + "]";
	}
	

}
