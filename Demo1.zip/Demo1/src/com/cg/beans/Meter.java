package com.cg.beans;

public class Meter {
	
	private int meterNo, consumptionUnits, phase, meterLoad;
	private Bill bill;
	public Meter() {}
	public Meter(int meterNo, int consumptionUnits, int phase, int meterLoad) {
		super();
		this.meterNo = meterNo;
		this.consumptionUnits = consumptionUnits;
		this.phase = phase;
		this.meterLoad = meterLoad;
	}	
	public Meter(int meterNo, int consumptionUnits, int phase, int meterLoad, Bill bill) {
		super();
		this.meterNo = meterNo;
		this.consumptionUnits = consumptionUnits;
		this.phase = phase;
		this.meterLoad = meterLoad;
		this.bill = bill;
	}
	public int getMeterNo() {
		return meterNo;
	}
	public void setMeterNo(int meterNo) {
		this.meterNo = meterNo;
	}
	public int getConsumptionUnits() {
		return consumptionUnits;
	}
	public void setConsumptionUnits(int consumptionUnits) {
		this.consumptionUnits = consumptionUnits;
	}
	public int getPhase() {
		return phase;
	}
	public void setPhase(int phase) {
		this.phase = phase;
	}
	public int getMeterLoad() {
		return meterLoad;
	}
	public void setMeterLoad(int meterLoad) {
		this.meterLoad = meterLoad;
	}	
	public Bill getBill() {
		return bill;
	}
	public void setBill(Bill bill) {
		this.bill = bill;
	}
	@Override
	public String toString() {
		return "Meter [meterNo=" + meterNo + ", consumptionUnits=" + consumptionUnits + ", phase=" + phase
				+ ", meterLoad=" + meterLoad + ", bill=" + getBill().toString() + "]";
	}	

}
