package com.cg.beans;

public class Address {
	
	private int doorNo, wardNo,pincode;
	private String streetName, areaName, city, state;
	public Address() {}
	public Address(int doorNo, int wardNo,int pincode, String streetName, String areaName, 
								String city, String state) {
		super();
		this.doorNo = doorNo;
		this.wardNo = wardNo;
		this.pincode = pincode;
		this.streetName = streetName;
		this.areaName = areaName;
		this.city = city;
		this.state = state;
	}	
	public Address(int doorNo, int pincode, String streetName, String state) {
		super();
		this.doorNo = doorNo;
		this.pincode = pincode;
		this.streetName = streetName;
		this.state = state;
	}
	public int getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}
	public int getWardNo() {
		return wardNo;
	}
	public void setWardNo(int wardNo) {
		this.wardNo = wardNo;
	}	
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	@Override
	public String toString() {
		return "Address [doorNo=" + doorNo + ", wardNo=" + wardNo + ", pincode=" + pincode + ", "
				+ "streetName="+ streetName + ", areaName=" + areaName + ", city=" + city + ", state=" + 
				state + "]";
	}
}
