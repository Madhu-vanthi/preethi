package com.cg.beans;

public class Bill {
	
	private String billDueDate,billNo,billAmount,billUnit,billMonth;
	public Bill() {}
	public Bill(String billDueDate, String billNo, String billAmount, String billUnit, String billMonth) {
		super();
		this.billDueDate = billDueDate;
		this.billNo = billNo;
		this.billAmount = billAmount;
		this.billUnit = billUnit;
		this.billMonth = billAmount;		
	}
	public Bill(String billNo, String billUnit) {
		super();
		this.billNo = billNo;
		this.billUnit = billUnit;
	}
	public String getBillDueDate() {
		return billDueDate;
	}
	public void setBillDueDate(String billDueDate) {
		this.billDueDate = billDueDate;
	}
	public String getBillNo() {
		return billNo;
	}
	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}
	public String getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(String billAmount) {
		this.billAmount = billAmount;
	}	
	public String getBillUnit() {
		return billUnit;
	}
	public void setBillUnit(String billUnit) {
		this.billUnit = billUnit;
	}
	public String getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
	@Override
	public String toString() {
		return "Bill [billDueDate=" + billDueDate + ", billNo=" + billNo + ", billAmount=" + billAmount + ", billUnit="
				+ billUnit + ", billMonth=" + billMonth + "]";
	}	

}
