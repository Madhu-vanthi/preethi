package com.cg.Util;

import java.util.HashMap;
import com.cg.beans.Customer;

public class ElectricityBillUtil {
	
private static int CUSTOMER_ID_COUNTER=100;
public static HashMap<Integer,Customer> customers = new HashMap<>();
	
	public static int getCUSTOMER_ID_COUNTER() {
		
		return ++CUSTOMER_ID_COUNTER;
		
	}

}
