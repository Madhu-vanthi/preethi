package comc.g.stepdefs;

import static org.testng.Assert.assertEquals;
import com.cg.math.Calculator;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FindSquareStepDefs {
	
	Calculator calcl;
	int res,errorCode;
	
	@Before
	public void beforeMethod() {
		System.out.println("I am in before method..");
	}
	
	@After
	public void afterMethod() {
		System.out.println("I am in after method..");
	}
	
	@Given("^create the calculator object$")
	public void create_the_calculator_object() throws Throwable  {
	   calcl = new Calculator();
	   System.out.println("In given step..");
	}

	@When("^user will give valid (\\d+) to find square method$")
	public void user_will_give_valid_to_find_square_method(int arg1) throws Throwable {
	   res = calcl.findSquare(arg1);
	   System.out.println("In when step..");
	}

	@Then("^method should return correct (\\d+)$")
	public void method_should_return_correct(int arg1) throws Throwable {
	   assertEquals(res,arg1);
	   System.out.println("In then step..");
	}

}
