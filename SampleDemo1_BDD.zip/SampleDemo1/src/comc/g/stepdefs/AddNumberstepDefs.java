package comc.g.stepdefs;

import static org.testng.Assert.assertEquals;
import com.cg.math.Calculator;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddNumberstepDefs {
	
	Calculator calcl;
	int res,errorCode;

	@Given("^user creates calculator object and call add method$")
	public void user_creates_calculator_object_and_call_add_method() throws Throwable {
	    calcl = new Calculator();
	}

	@When("^user will pass valid input$")
	public void user_will_pass_valid_input() throws Throwable {
	   res = calcl.add(4, 5);
	}

	@Then("^add method should return correct result$")
	public void add_method_should_return_correct_result() throws Throwable {
	    assertEquals(res,9);
	}

	@When("^user gives one valid and one invalid input$")
	public void user_gives_one_valid_and_one_invalid_input() throws Throwable {
		errorCode = calcl.add(10, -6);
	}

	@Then("^add method should return error code$")
	public void add_method_should_return_error_code() throws Throwable {
	   assertEquals(errorCode, -1);
	}

}
