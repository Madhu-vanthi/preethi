package com.cg.dto;

import java.util.List;
import java.util.regex.Pattern;

public class Service {

	public String validateMobileList(List<String> list) {		
		String message;
		String regex = "^[0-9]{10}$";
		boolean flag = true;
		
		for(String mobno : list) {
			
			if(Pattern.matches(regex, mobno))
				continue;
			
		}		
		
		if(!flag) 
			message="Invalid numbers are present in Data Table";		
		else
			message="All numbers are valid";
		
		return message;
		
	}
}
