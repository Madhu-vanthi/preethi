package com.cg.math;

public class Calculator {

	public int add(int i,int j) {
		if(i<=0 || j<=0)
			return -1;
		else
			return i+j;
	}

	public int findSquare(int i) {
		return i*i;
	}
}
