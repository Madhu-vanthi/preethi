package com.cg.banking.client;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingSystem {

	public static void main(String[] args) {
		/*
		Transaction[] transactions=new Transaction[] {
				new Transaction(969,2500,"Business","Success"),
				new Transaction(645,4000,"Business","Failed"),
				new Transaction(256,6000,"Financial","NoBalance")};

		Account[] accounts=new Account[3];

		accounts[0]=new Account(3465,56000.65,"Savings",getTransaction());		
		*/
		
		Transaction[] transaction1=new Transaction[]
	            {
	        new Transaction(124564, 5000, "Online", "Success"),
	        new Transaction(456121, 2500, "Offline", "Success"),
	        new Transaction(564513, 5200, "Offline", "Failed"),
	        new Transaction(542134, 1200, "Online","Pending")
	    };
	    Transaction[] transaction2=new Transaction[] 
	            {
	            		 new Transaction(454351, 2900, "Online", "Fail"),
	         	        new Transaction(441324, 300, "Offline", "Success"),
	         	        new Transaction(567423, 9000, "Offline", "Failed"),
	        };
	    Account [] account=new Account[] 
	            {
	                    new Account(101101, 8000, "Savings", transaction1),
	                    new Account(101102, 45000, "current", transaction2)
	            };
	    Customer c1=new Customer(101, 45414435, "preethi", "saamanna", account);
	        for(int i=0;i<account.length;i++)
	            for(int j=0;j<transaction1.length-1;j++)
	                if(c1.getAccount()[i].getTransaction()[j].getTransactionID()==454351) {
	                    System.out.println("At"+" "+c1.getAccount()[i].getTransaction()[j].getTimeStamp()+"done by");
	                    
	                }
	}

}
