package com.cg.banking.beans;

public class Customer {

	private int customerID,mobileNum,adharNum;
	private String firstName,lastname,emailID,pancardNum,dateOfBirth;
	private Account[] account;
	
	public Customer() {
	}
	
	public Customer(int customerID, int mobileNum, int adharNum, String firstName, String lastname, String emailID,
			String pancardNum, String dateOfBirth, Account[] account) {
		super();
		this.customerID = customerID;
		this.mobileNum = mobileNum;
		this.adharNum = adharNum;
		this.firstName = firstName;
		this.lastname = lastname;
		this.emailID = emailID;
		this.pancardNum = pancardNum;
		this.dateOfBirth = dateOfBirth;
		this.account = account;
	}
	public Customer(int customerID, int adharNum, String firstName, String lastname, Account[] account) {
		super();
		this.customerID = customerID;
		this.adharNum = adharNum;
		this.firstName = firstName;
		this.lastname = lastname;
		this.account = account;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public int getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(int mobileNum) {
		this.mobileNum = mobileNum;
	}

	public int getAdharNum() {
		return adharNum;
	}

	public void setAdharNum(int adharNum) {
		this.adharNum = adharNum;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getPancardNum() {
		return pancardNum;
	}

	public void setPancardNum(String pancardNum) {
		this.pancardNum = pancardNum;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Account[] getAccount() {
		return account;
	}

	public void setAccount(Account[] account) {
		this.account = account;
	}
	
}
