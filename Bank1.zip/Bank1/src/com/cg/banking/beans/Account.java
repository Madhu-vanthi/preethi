package com.cg.banking.beans;

import java.util.Arrays;

public class Account {
	
	private int accountNum;
	private float accountBalance;
	private String accountType;
	private Transaction[] transaction;
	
	public Account() {
	}
	public Account(int accountNum, float accountBalance, String accountType) {
		super();
		this.accountNum = accountNum;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		
	}
	public Account(int accountNum, float accountBalance, String accountType, Transaction[] transaction) {
		super();
		this.accountNum = accountNum;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.transaction = transaction;
	}
	public int getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Transaction[] getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction[] transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() {
		return "Account [accountNum=" + accountNum + ", accountBalance=" + accountBalance + ", accountType="
				+ accountType + ", transaction=" + Arrays.toString(transaction) + "]";
	}
	
	
}