package comc.g.pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PersonalDetailsPageFactory {

	WebDriver driver;

	public PersonalDetailsPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//step 1 : Identifying the elements
		@FindBy(how=How.NAME, using="txtFN")
		@CacheLookup
		WebElement cardHolderName;
	
		@FindBy(id="txtDebit")
		@CacheLookup
		WebElement debitCardNo;
	
		@FindBy(xpath=".//*[@id='txtCvv']")
		@CacheLookup
		WebElement cvv;
	
		@FindBy(name="month")
		@CacheLookup
		WebElement month;
	
		@FindBy(name="year")
		@CacheLookup
		WebElement year;
		
		@FindBy(id="btnPayment")
		@CacheLookup
		WebElement makePayment;

	//step 2 : Getters and Setters
		public WebElement getCardHolderName() {
			return cardHolderName;
		}

		public void setCardHolderName(String HolderName) {
			cardHolderName.sendKeys(HolderName);
		}

		public WebElement getDebitCardNo() {
			return debitCardNo;
		}

		public void setDebitCardNo(String CardNo) {
			debitCardNo.sendKeys(CardNo);
		}

		public WebElement getCvv() {
			return cvv;
		}

		public void setCvv(String Cvv) {
			cvv.sendKeys(Cvv);
		}

		public WebElement getMonth() {
			return month;
		}

		public void setMonth(String Month) {
			month.sendKeys(Month);
		}

		public WebElement getYear() {
			return year;
		}

		public void setYear(String Year) {
			year.sendKeys(Year);
		}

		public WebElement getMakePayment() {
			return makePayment;
		}

		public void setMakePayment() {
			makePayment.click();
		}		
}
