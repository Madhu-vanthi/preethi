package com.cg.Demo.client;

import com.cg.Demo.beans.Correspondance;
import com.cg.Demo.beans.PartTime;
import com.cg.Demo.beans.Regular;
import com.cg.Demo.beans.Student;

public class MainClass {

	public static void main(String[] args) {

		Student s;
		
		s=new Regular(11,"madhu","vanthi",76,56,45,90);
		s.calculate();
		Regular r=(Regular)s;
		r.print();
		System.out.println(s.getRollNo()+" "+s.getFirstName()+" "+s.getLastName()+" "+s.getTotal());
		
		s=new Correspondance(101,"gopika","ankani",45,56,67);
		s.calculate();
		Correspondance c=(Correspondance)s;
		c.print();
		System.out.println(s.getRollNo()+" "+s.getFirstName()+" "+s.getLastName()+" "+s.getTotal());
		
	}

}
