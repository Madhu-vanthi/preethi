package com.cg.collections.client;

import java.util.List;
import java.util.ArrayList;
import com.cg.collections.collection.Condition;
import com.cg.collections.beans.Associate;
import com.cg.collections.collections.ListClassesDemo;

public class MainClass {

	public static void main(String[] args) {
		
		
		ListClassesDemo.ArrayListClassDemo();
		
		
	}
	
}
