package com.cg.collections.collections;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

import com.cg.collections.beans.Associate;
import com.cg.collections.collection.Condition;

public class ListClassesDemo {
	public static void ArrayListClassDemo(){

	ArrayList <Associate> associates = new ArrayList<>();
	
	//insert	
	associates.add(new Associate(111,15000,"madhu","vanthi"));
	associates.add(new Associate(112,20000,"gopi","ankani"));
	associates.add(new Associate(114,10000,"aanchal","srivastava"));
	associates.add(new Associate(113,35000,"lakshmi","manchu"));		
	
	//search	
	Associate associateToBeSearch = new Associate(113,35000,"lakshmi","manchu");
	int idx = associates.indexOf(associateToBeSearch);
	//Associate associate = associates.get(idx);
	System.out.println(idx);
	
	//remove	
	System.out.println(associates.remove(2));
	
	//sort	
	/*Collections.sort(associates);
	System.out.println(associates);*/
	
	/*Collections.sort(associates, new AssociateComparator());
	System.out.println(associates);*/
	
	/*Comparator<Associate> assComparator = (a1,a2)->a1.getBasicSalary()-a2.getBasicSalary();
	Collections.sort(associates, assComparator);*/
	
	Collections.sort(associates,(a1,a2)->a1.getBasicSalary()-a2.getBasicSalary());
	System.out.println(associates);
	
	printAssociateDetails(associates,a->a.getFirstName().startsWith("a"));		
	Stream<Associate> stream1 = associates.stream();
	Stream<Associate> stream2 = stream1.distinct();
	Stream<Associate> stream3 = stream2.filter((associate)->associate.getFirstName().startsWith("a"));
	stream3.forEach((associate)->System.out.println(associates));
	
	/*associates.stream()
	.distinct()
	.filter((associate)->associate.getFirstName().startsWith("a"))
	forEach(associate->System.out.println(associate));

    associates1.stream().distinct().filter((a)->a.getFirstName().startsWith("a")).forEach((a)->System.out.println(a));
    System.out.println(associates1.stream().map(associate->associate.getAssociateId()));*/
	
	
	}
	private static void printAssociateDetails(List<Associate>associates, Condition condition) {
		for(Associate associate:associates)			
			if(condition.startWith(associate))
				System.out.println(associates);	
	}
	 private static void printEmployeeDetails2(List<Associate> associates,Predicate<Associate>predicate,Consumer<Associate>consumer){
	        for (Associate associate : associates) {
	            if(predicate.test(associate))
	                consumer.accept(associate);
	        }

	 }
	
	

}
	
