package com.cg.collections.collections;

import java.util.Comparator;

import com.cg.collections.beans.Associate;

public class AssociateComparator implements Comparator <Associate>{

	@Override
	public int compare(Associate associate1, Associate associate2) {
		
		return 0;
	}
	
	

}
