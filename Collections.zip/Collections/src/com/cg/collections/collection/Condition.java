package com.cg.collections.collection;
import com.cg.collections.beans.Associate;

@FunctionalInterface
public interface Condition {

	boolean startWith(Associate associate);
}
