package com.cg.project.servlets;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;    
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;

@WebServlet("/registrationSuccessPage")
public class RegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;  
       
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String firstName=request.getParameter("firstName");  
        String lastName=request.getParameter("lastName");         
        String password=request.getParameter("password");   
        String emailId=request.getParameter("emailId");     
        String gender=request.getParameter("gender");     
        int mobileNo =Integer.parseInt(request.getParameter("mobileNo"));  
        String graduation=request.getParameter("graduation");      
        String [] communications=request.getParameterValues("communication");
        
        List<String> communicationsList = new ArrayList<>(Arrays.asList(communications));  
        UserBean userBean=new UserBean(password, firstName, lastName, emailId, mobileNo, gender, graduation, communicationsList);
        RequestDispatcher dispatcher=request.getRequestDispatcher("registrationSuccessPage.jsp");      
        request.setAttribute("bean", userBean);               
        dispatcher.forward(request, response);                  
    }    
}
		

