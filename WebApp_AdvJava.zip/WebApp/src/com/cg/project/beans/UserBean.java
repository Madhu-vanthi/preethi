package com.cg.project.beans;

import java.util.List;

public class UserBean {
	
private int associateId;
private String password,firstName,lastName,emailId,gender,graduation;
int mobileNo;
private List<String>communications;

public UserBean() {}
public UserBean(int associateId, String password) {
	super();
	this.associateId = associateId;
	this.password = password;
}

public UserBean( String password, String firstName, String lastName, String emailId, int mobileNo,
		String gender, String graduation, List<String> communications) {
	super();
	
	this.password = password;
	this.firstName = firstName;
	this.lastName = lastName;
	this.emailId = emailId;
	this.mobileNo = mobileNo;
	this.gender = gender;
	this.graduation = graduation;
	this.communications = communications;
}

public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public int getMobileNo() {
	return mobileNo;
}
public void setMobileNo(int mobileNo) {
	this.mobileNo = mobileNo;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getGraduation() {
	return graduation;
}
public void setGraduation(String graduation) {
	this.graduation = graduation;
}
public List<String> getCommunications() {
	return communications;
}
public void setCommunications(List<String> communications) {
	this.communications = communications;
}
public int getAssociateId() {
	return associateId;
}
public void setAssociateId(int associateId) {
	this.associateId = associateId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}
