package com.cg.Interface.Services;

import com.cg.Interface.Exception.InvalidNumberRangeException;

public class MathServicesImpl implements MathServices{

	@Override
	public int add(int n1, int n2) throws InvalidNumberRangeException {
		
		if(n1>=0 && n2>=0) 		
			return n1+n2;
		else
			throw new InvalidNumberRangeException();
	}

	@Override
	public int sub(int n1, int n2) throws InvalidNumberRangeException {
		
		if(n1>=0 && n2>=0)
			return n1-n2;
		else
			throw new InvalidNumberRangeException();
	}

	@Override
	public int multiply(int n1, int n2) throws InvalidNumberRangeException {
		if(n1>=0 && n2>=0)
			return n1*n2;
		else
			throw new InvalidNumberRangeException();
	}

	@Override
	public int div(int n1, int n2) throws InvalidNumberRangeException {
		if(n1>=0 && n2>=0)
			return n1/n2;
		else
			throw new InvalidNumberRangeException();
	}

	
}
