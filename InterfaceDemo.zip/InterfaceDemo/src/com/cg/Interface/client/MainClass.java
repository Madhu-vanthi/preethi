package com.cg.Interface.client;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.Interface.Exception.InvalidNumberRangeException;
import com.cg.Interface.Services.*;


public class MainClass {

	public static void main(String[] args) {
		
		MathServices mathServices = new MathServicesImpl();
		try {
			System.out.println(mathServices.add(100, 200));
			System.out.println(mathServices.sub(100, 200));
			System.out.println(mathServices.multiply(100, 200));
			System.out.println(mathServices.div(100, 200));
		} catch (InvalidNumberRangeException e1) {
			
			e1.printStackTrace();
		}
		
	}
}
