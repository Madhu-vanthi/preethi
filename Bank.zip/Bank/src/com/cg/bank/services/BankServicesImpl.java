package com.cg.bank.services;
import javax.swing.text.DefaultEditorKit.CutAction;
import com.cg.bank.customer.Account;
import com.cg.bank.customer.Address;
import com.cg.bank.customer.Customer;
import com.cg.bank.customer.Transaction;
import com.cg.bank.customernotfoundexception.CustomerNotFoundException;
import com.cg.bank.daoservices.CustomerDao;
import com.cg.bank.daoservices.CustomerDaoImpl;
public class BankServicesImpl implements BankService{	
	
private CustomerDao customerDao=new CustomerDaoImpl();

@Override
public int acceptCustomerDetails(int customerID, int mobileNo, int aadharNo, int dofBirth, String firstName,
		String lastName, String emailID, String panID, String city, String state, String country, int accountNo,
		int accountBalance, String accountType) {
Customer customer=new Customer(mobileNo, aadharNo, dofBirth, firstName, lastName, emailID, panID, new Account(accountNo, accountBalance, accountType));
customerDao.save(customer);
return customer.getCustomerID();
}
@Override
public int deposit(int amount,int customerID) throws CustomerNotFoundException {
	Customer customer=customerDao.findOne(customerID);
	Account account=customer.getAccount();
	account.setAccountBalance(account.getAccountBalance()+amount);
	return (account.getAccountBalance());	
}
@Override
public int withDraw(int amount,int customerID) throws CustomerNotFoundException {
	Customer customer=customerDao.findOne(customerID);
Account account=customer.getAccount();	
	account.setAccountBalance(account.getAccountBalance()-amount);
	return account.getAccountBalance();
	
}

@Override
public Customer getCustomerDetails(int customerID) throws CustomerNotFoundException {
	
	Customer customer=customerDao.findOne(customerID);
	if(customer==null)throw new CustomerNotFoundException();
	return customer;
	
}

}
