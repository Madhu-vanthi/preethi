package com.cg.payroll.test;

import org.junit.Before;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;


import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;

public class PayrollServiceTest {
	/*public static PayrollServices payrollServices;
	@BeforeClass
	public static void setUpTestEnv() {
		payrollServices=new PayrollServicesImpl();
	}
	@Before
	public void setUpTestData() {
		Associate associate1=new Associate(101, 200000, "gopi", "ankani", "java trainee", "analyst", "HAHI27979", "gopi@gmail.com", 
				new Salary(20000, 2000, 3000), new BankDetails(100086699, "HDFC", "hdfc997"));
		Associate associate2=new Associate(102, 190000, "sadhik", "shaik", "java trainee", "analyst", "HSD97979", "sadhik@gmail.com", 
				new Salary(20000, 2000, 3000), new BankDetails(10008808, "HDFC", "hdfc997"));
		PayrollUtil.associates.put(associate1.getAssociateID(), associate1);
		PayrollUtil.associates.put(associate2.getAssociateID(), associate2);
		PayrollUtil.ASSOCIATE_ID_COUNTER=102;
	}
	@Test
	public void testAcceptAssociateDetailsForValidData() {
		int expectedAssociateId=103;
		int actualAssociateId=payrollServices.acceptAssociateDetails("teja", "hemanth", "teja@gmail.com", "trainee", "Anaylyst", 
				"DHF3834", 200000, 20000, 7000, 2000, 2034024, "ICICI", "icici4804");
		Assert.assertEquals(expectedAssociateId, actualAssociateId);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssoiciateId()throws AssociateDetailsNotFoundException{
		payrollServices.getAsscoiateDetails(179);
	}
	@Test
	public void testGetAssociateDataForValidAssociateId()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(102, 190000, "sadhik", "shaik", "java trainee", "analyst", "HSD97979", "sadhik@gmail.com", 
				new Salary(20000, 2000, 3000), new BankDetails(10008808, "HDFC", "hdfc997"));
		Associate actualAssociate=payrollServices.getAsscoiateDetails(102);
		Assert.assertEquals(expectedAssociate, actualAssociate);
		}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalcualteNetSalaryForInvalidAssociateId()throws AssociateDetailsNotFoundException{
		payrollServices.getAsscoiateDetails(179);
	}
	@Test
	public void testCalcualteNetSalaryForvalidAssociateId()throws AssociateDetailsNotFoundException{
		float expectedNetSalary=33666.0f;
		float actualNetSalary=payrollServices.calculateNetSalary(102);
		Assert.assertEquals(expectedNetSalary, actualNetSalary, 500 );
	}
	@Test
	public void testForGetAllAssociateDetails() {
		ArrayList<Associate> expectedAssociateList=new ArrayList<>(PayrollUtil.associates.values());
		ArrayList<Associate> actualAssociateList=(ArrayList<Associate>) payrollServices.getAllAssociateDetails();
		Assert.assertEquals(expectedAssociateList, actualAssociateList);
	}
	@After
	public void tearDownTestData() {
		PayrollUtil.ASSOCIATE_ID_COUNTER=100;
		PayrollUtil.associates.clear();
	}
	@AfterClass
	public static void tearDownTestEnv() {
		payrollServices=null;
	}
*/
}

