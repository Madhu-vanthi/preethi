package com.cg.bean.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.dto.Account;
import com.cg.bean.service.BankingServiceImpl;

public class BankingController {
	
	Account account;

	@Autowired
	BankingServiceImpl bankingService;

	public BankingServiceImpl getBankingService() {
		return bankingService;
	}

	public void setBankingService(BankingServiceImpl bankingService) {
		this.bankingService = bankingService;
	}
	
	@RequestMapping(value="ShowBankingOperationsPage")
	public String ShowBankOperationsPage(Model model) {
		return "BankingOperations";
	}	
	
	@RequestMapping(value="ShowOpenAccountPage")
	public String ShowOpenAccount(Model model) {
		model.addAttribute("account", account);
		return "OpenAccount";
	}
	
	@RequestMapping(value="OpenningAccount", method=RequestMethod.POST)
	public String AccountOpenning(@ModelAttribute(value="account")Account acc,Model model) {
		account = bankingService.openAccount(acc.getHolderName(),acc.getAccountType(),acc.getAccountBalance());		
		model.addAttribute("acc", account);
		return "OpenAccount";
	}
	
	@RequestMapping(value="DisplayOpennedAccount", method=RequestMethod.POST)
	public String DisplayAccountOpenning(@ModelAttribute(value="acc")Account acc,Model model) {
		model.addAttribute("msg", "Account opened successfully");
		return "OpenAccount";
	}
	
	@RequestMapping(value="ShowDepositOptionPage")
	public String ShowDepositOption(Model model) {
		model.addAttribute("deposit", account);
		return "DepositAmount";
	}
	
	@RequestMapping(value="DepositAmount", method=RequestMethod.POST)
	public String AmountDeposition(@ModelAttribute(value="deposit")Account acc,Model model) {
		account = bankingService.depositAmount(acc.getAccountNo(), acc.getTransactions().getAmount());
		model.addAttribute("acc", account);
		return "DepositAmount";
	}
	
	@RequestMapping(value="DisplayDepositionBalance", method=RequestMethod.POST)
	public String DisplayAmountDeposition(@ModelAttribute(value="acc")Account acc,Model model) {
		model.addAttribute("msg", "Deposition done successfully");
		return "DepositAmount";
	}
	
	@RequestMapping(value="ShowWithdrawOptionPage")
	public String ShowWithdraw(Model model) {
		model.addAttribute("withdraw", new Account());
		return "WithdrawAmount";
	}
	
	@RequestMapping(value="WithdrawAmount", method=RequestMethod.POST)
	public String AmountWithdrawal(@ModelAttribute(value="withdraw")Account acc,Model model) {
		account = bankingService.withdrawAmount(acc.getAccountNo(), acc, acc.getPinNumber());
		model.addAttribute("acc", account);
		return "WithdrawAmount";
	}
	
	@RequestMapping(value="DisplayWithdrawalBalance", method=RequestMethod.POST)
	public String DisplayAmountWithdrawal(@ModelAttribute(value="acc")Account acc,Model model) {
		model.addAttribute("msg", "Withdrawal of amount done successfully");
		return "WithdrawAmount";
	}
	
	@RequestMapping(value="ShowFundTransferPage")
	public String ShowFundTransfer(Model model) {
		model.addAttribute("fund", account);
		return "FundTransfer";
	}
	
	@RequestMapping(value="TransferAmount", method=RequestMethod.POST)
	public String TransferringAmount(@ModelAttribute(value="fund")Account acc,Model model) {
		account = bankingService.fundTransfer(acc.get, acc.getAccountNo(), acc.getTransactions()., acc.getPinNumber());
		model.addAttribute("acc", account);
		return "FundTransfer";
	}
	
	@RequestMapping(value="DisplayTransferredBalance", method=RequestMethod.POST)
	public String DisplayAmountTransferred(@ModelAttribute(value="acc")Account acc,Model model) {
		model.addAttribute("msg", "Amount is successfully transferred");
		return "FundTransfer";
	}
	
	@RequestMapping(value="ShowGetAccountPage")
	public String ShowGetAccountDetail(Model model) {
		model.addAttribute("find", account);
		return "FindAccount";
	}
	
	@RequestMapping(value="FindAnAccount", method=RequestMethod.POST)
	public String FindingAccount(@ModelAttribute(value="find")Account acc,Model model) {
		account = bankingService.getAccountDetails(acc.getAccountNo());
		model.addAttribute("acc", account);
		return "FindAccount";
	}
	
	@RequestMapping(value="DisplayFindingAccount", method=RequestMethod.POST)
	public String DisplayOfAnAccount(@ModelAttribute(value="acc")Account acc,Model model) {
		model.addAttribute("msg", "Displaying An Account");
		return "FindAccount";
	}
	
	@RequestMapping(value="ShowGetAllAccountPage")
	public String ShowGetAllAccountDetail(Model model) {
		List<Account> accounts = bankingService.getAllAccountDetails();
		model.addAttribute("msg", "All Account details");
		model.addAttribute("accountList", accounts);
		return "FindAllAccount";
	}
	
	@RequestMapping(value="FindAllTransactions")
	public String FindingTransactions(Model model) {
		model.addAttribute("transaction", account);
		return "AllTransactions";
	}
	
	@RequestMapping(value="DisplayAllTransactions", method=RequestMethod.POST)
	public String DisplayOfAllTransactions(@ModelAttribute(value="transaction")Account acc,Model model) {
		List<Account> accounts = bankingService.getAccountAllTransaction(acc.getTransactions());
		model.addAttribute("msg", "Displaying All Transactions");
		model.addAttribute("accountList", accounts);
		return "AllTransactions";
	}
}
