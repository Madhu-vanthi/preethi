package com.cg.bean.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.dao.AccountDaoImpl;
import com.cg.bean.dao.TransactionDaoImpl;
import com.cg.bean.dto.Account;
import com.cg.bean.dto.Transaction;

@Service
public class BankingServiceImpl implements IBankingService{

	@Autowired
	AccountDaoImpl accountDao;
	
	@Autowired
	TransactionDaoImpl transactionDao;
	
	Account account;

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public AccountDaoImpl getAccountDao() {
		return accountDao;
	}

	public void setAccountDao(AccountDaoImpl accountDao) {
		this.accountDao = accountDao;
	}

	public TransactionDaoImpl getTransactionDao() {
		return transactionDao;
	}

	public void setTransactionDao(TransactionDaoImpl transactionDao) {
		this.transactionDao = transactionDao;
	}

	@Override
	public Account openAccount(String name,String accountType,float accountBalance) {
		account.setHolderName(name);
		account.setAccountBalance(accountBalance);
		account.setAccountType(accountType);
        account.setPinNumber((int)Math.random()*1235);
        account.setStatus("Active");
		return accountDao.openAccount(account);
	}

	@Override
	public Account depositAmount(long accountNo, float amount) {
		account = this.getAccountDetails(accountNo);
		account.setAccountBalance(account.getAccountBalance()+amount);
		return accountDao.updateAccount(account);
	}

	@Override
	public Account withdrawAmount(long accountNo, float amount, int pinNumber) {
		account = this.getAccountDetails(accountNo);
		if(pinNumber==account.getPinNumber())
			account.setAccountBalance(account.getAccountBalance()-amount);
		return accountDao.updateAccount(account);
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) {
		Account accountFrom = this.getAccountDetails(accountNoFrom);
		Account accountTo = this.getAccountDetails(accountNoTo);
		if(pinNumber==account.getPinNumber()) {
			accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
			accountTo.setAccountBalance(accountTo.getAccountBalance()+transferAmount);
		}
		return accountDao.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber);
	}

	@Override
	public Account getAccountDetails(long accountNo) {
		return accountDao.getAccountDetails(accountNo);
	}

	@Override
	public List<Account> getAllAccountDetails() {
		return accountDao.getAllAccountDetails();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) {
		return accountDao.getAccountAllTransaction(accountNo);
	}
	
	
}
