package com.cg.bean.dao;

import java.util.List;
import com.cg.bean.dto.Account;
import com.cg.bean.dto.Transaction;

public interface ITransactionDao {

	public Account openAccount();
	public float depositAmount(long accountNo,float amount);
	public float withdrawAmount(long accountNo,float amount,int pinNumber);
	public boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber);
	public Account getAccountDetails(long accountNo);
	public List<Account> getAllAccountDetails();
	public List<Transaction> getAccountAllTransaction(long accountNo);
}
