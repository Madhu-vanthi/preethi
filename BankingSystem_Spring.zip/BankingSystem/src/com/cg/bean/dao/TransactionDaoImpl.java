package com.cg.bean.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.bean.dto.Account;
import com.cg.bean.dto.Transaction;

@Repository("transactionDao")
@Transactional
public class TransactionDaoImpl implements ITransactionDao{

	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Account openAccount() {
		return null;
	}

	@Override
	public float depositAmount(long accountNo, float amount) {
		return 0;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) {
		return 0;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) {
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNo) {
		return null;
	}

	@Override
	public List<Account> getAllAccountDetails() {
		return null;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) {
		return null;
	}

}
