package com.cg.bean.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.dto.Account;
import com.cg.bean.dto.Transaction;

@Repository("accountDao")
@Transactional
public class AccountDaoImpl implements IAccountDao{

	@PersistenceContext
	EntityManager entityManager;
	
	Account acc;
	
	@Override
	public Account openAccount(Account account){
		entityManager.persist(account);
		return account;
	}

	@Override
	public Account updateAccount(Account account) {
		acc = entityManager.merge(account);
		return acc;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) {
		return 0;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) {
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNo) {		
		return entityManager.find(Account.class, accountNo);
	}

	@Override
	public List<Account> getAllAccountDetails() {
		return entityManager.createQuery("from Account acc").getResultList();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) {
		List<Transaction> transactions = (List<Transaction>) entityManager.find(Transaction.class, accountNo);
		return transactions;
	}

}
