package com.cg.client;

import com.cg.beans.*;

public class MainClass {

	public static void main(String[] args) {
		int n=100,n1;
		Integer iob=n;
		n1=n+iob;
		Associate a1=new Associate( 111, 25000, 30000, "madhu", "vanthi",
				new Address("coimbatore","tamilnadu"));
		Associate a2=new Associate( 111, 25000, 30000, "madhu", "vanthi",
				new Address("coimbatore","tamilnadu"));
		Associate a3=new Associate( 112, 20000, 24000, "gopa", "kumari",
				new Address("west godavari","andhra pradesh"));		
		System.out.println(a1);
		System.out.println(a3);	
		if(a1==a2)
			System.out.println("same");
		else
			System.out.println("not same");
		if(a1.equals(a2))
			System.out.println("same");
		else
			System.out.println("not same");
		

	}

}
