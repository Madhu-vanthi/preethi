package com.cg.beans;

public class Associate {
	
	private int assId,basicSalary,totalSalary;
	private String fName,lName;
	private Address address;
	public Associate() {}
	public Associate(int assId, int basicSalary, int totalSalary, String fName, 
			String lName, Address address) {
		super();
		this.assId = assId;
		this.basicSalary = basicSalary;
		this.totalSalary = totalSalary;
		this.fName = fName;
		this.lName = lName;
		this.address = address;
	}
	public int getAssId() {
		return assId;
	}
	public void setAssId(int assId) {
		this.assId = assId;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public int getTotalSalary() {
		return totalSalary;
	}
	public void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + assId;
		result = prime * result + basicSalary;
		result = prime * result + ((fName == null) ? 0 : fName.hashCode());
		result = prime * result + ((lName == null) ? 0 : lName.hashCode());
		result = prime * result + totalSalary;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (assId != other.assId)
			return false;
		if (basicSalary != other.basicSalary)
			return false;
		if (fName == null) {
			if (other.fName != null)
				return false;
		} else if (!fName.equals(other.fName))
			return false;
		if (lName == null) {
			if (other.lName != null)
				return false;
		} else if (!lName.equals(other.lName))
			return false;
		if (totalSalary != other.totalSalary)
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Associate [assId=" + assId + ", basicSalary=" + basicSalary + ", totalSalary=" + totalSalary
				+ ", fName=" + fName + ", lName=" + lName + ", address=" + getAddress().toString()+ "]";
	}
}