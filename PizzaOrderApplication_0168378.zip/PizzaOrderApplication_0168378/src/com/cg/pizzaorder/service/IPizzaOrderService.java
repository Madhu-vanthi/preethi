package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.InvalidPhoneNumberException;
import com.cg.pizzaorder.exception.InvalidToppingException;

public interface IPizzaOrderService {
         
boolean valPhone(Customer customer); 
double calPizzaPrice(PizzaOrder pizza) throws InvalidToppingException;
int placeOrder(Customer customer, PizzaOrder pizza) throws InvalidPhoneNumberException, InvalidToppingException, InvalidToppingException;
PizzaOrder getOrderDetails(int orderId); 
}  


