package com.cg.pizzaorder.ui;

import java.util.Scanner;
import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.CustomerDetailsNotFound;
import com.cg.pizzaorder.exception.InvalidPhoneNumberException;
import com.cg.pizzaorder.exception.InvalidToppingException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;
 
public class Client {

    public static void main(String[] args) {    	
     
			try {
				IPizzaOrderService pizzaOrderService = new PizzaOrderService();
				Scanner scanner = new Scanner(System.in);  
 
				int choice = 0;
				do {
				    System.out.println("JUST EAT PIZZAS" + "\n 1. Place Order" + "\n 2. Display Order"
				            + "\n 3. Exit");
				    choice = scanner.nextInt(); 

				    switch (choice) { 
				    case 1:
				        String custName, address, phone, topping;
				        System.out.println("Enter name of the customer : ");
				        custName = scanner.next();
				        System.out.println("Enter address of the customer : ");
				        address = scanner.next();
				        System.out.println("Enter phone number of the customer : ");
				        phone = scanner.next();
				        System.out.println("Type of pizza toping referred : ");
				        topping = scanner.next();
				        Customer customer = new Customer(custName, address, phone); 
				        PizzaOrder pizza = new PizzaOrder();   
				        pizza.setTopping(topping);
				     
				            System.out.println("Your pizza order is successfully placed with order id " + pizzaOrderService.placeOrder(customer, pizza));
				            System.out.println("Remember your customer id " + pizza.getCustomerId());             
				        break;
				        
				    case 2:  
				        int orderId = 0;
				        System.out.println("Enter order id : ");
				        orderId = scanner.nextInt();
				        PizzaOrder order = pizzaOrderService.getOrderDetails(orderId);
				        System.out.println(order.toString());
				        break; 

				    case 3:  
				         System.out.println("Exited.... \n\nThank you");
				         System.exit(0);
				         break;        
				    default:
				        
				        System.out.println("Invalid Choice.....");  
				        break;
				    } 
				} while (choice != 3);
			} catch (Exception e) {
				
				e.printStackTrace();
			}			
			

    }
}
