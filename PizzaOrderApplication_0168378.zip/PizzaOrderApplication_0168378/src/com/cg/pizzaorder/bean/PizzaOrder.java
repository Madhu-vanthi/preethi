package com.cg.pizzaorder.bean;

public class PizzaOrder { 
    private int orderId;
    private int customerId;
    private String topping;
    private double totalPrice;

    public PizzaOrder() {    
    }

    public PizzaOrder(int orderId, int customerId, double totalPrice) {
        super();
        this.orderId = orderId; 
        this.customerId = customerId;
        this.totalPrice = totalPrice;
    }
 
    public PizzaOrder(int orderId, String topping) {
        super();
        this.orderId = orderId; 
        this.topping = topping;
    }

    //////////////////////////GETTERS & SETTERS//////////////////////////////////////////
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId; 
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getTopping() {
        return topping;
    }

    public void setTopping(String topping) {
        this.topping = topping;
    }

    ///////////////////////HASHCODE & EQUALS///////////////////////////
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + customerId;
        result = prime * result + orderId;
        result = prime * result + ((topping == null) ? 0 : topping.hashCode());
        long temp;
        temp = Double.doubleToLongBits(totalPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PizzaOrder other = (PizzaOrder) obj;
        if (customerId != other.customerId)
            return false;
        if (orderId != other.orderId)
            return false;
        if (topping == null) {
            if (other.topping != null)
                return false;
        } else if (!topping.equals(other.topping))
            return false;
        if (Double.doubleToLongBits(totalPrice) != Double.doubleToLongBits(other.totalPrice))
            return false;
        return true; 
    }  
    @Override
    public String toString() {
        return "PizzaOrder [orderId=" + orderId + ", customerId=" + customerId + ", topping=" + topping
                + ", totalPrice=" + totalPrice + "]";
    }
}