import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.service.PizzaOrderService;

public class PizzaOrderTestCase {

	static PizzaOrderService pizzaOrder;
	@BeforeClass
	public static void setUpTestEnv() {
		pizzaOrder = new PizzaOrderService();		
	}
	@Before
	public void setUpTestData() {
		PizzaOrder pizzaOrder = new PizzaOrder(120,2454,520);
		
	}
	
    @After
	public void tearDownTestData() {
	
		
	}
	@AfterClass
	public static void tearDownTestEnv() {
		pizzaOrder=null;
	}	
	

}
