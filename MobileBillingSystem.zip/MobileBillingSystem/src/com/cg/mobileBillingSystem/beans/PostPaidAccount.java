package com.cg.mobileBillingSystem.beans;

public class PostPaidAccount {

	private int mobileNum;
	private Bill[] bills=new Bill[3];
	private Address address;
	private Plan plan;
	public PostPaidAccount() {
	}
	public PostPaidAccount(int mobileNum) {
		super();
		this.mobileNum = mobileNum;
	}
	public int getMobileNum() {
		return mobileNum;
	}
	public void setMobileNum(int mobileNum) {
		this.mobileNum = mobileNum;
	}
}
