package com.cg.mobileBillingSystem.beans;

public class Bill {

	private int billID,noOfLocalSms,noOfStdSms,noOfStdCalls,noOfLocalCalls;
	private float internetDataUsageUnits,internetDataUsageUnitsAmount,billMonth,stateGST,centralGST,
	                         totalBillAmount,localSmsAmount,stdSmsAmount,localCallAmount,stdCallAmount;
	
	public Bill(int billID, int noOfLocalSms, int noOfStdSms, int noOfStdCalls, int noOfLocalCalls,
			float internetDataUsageUnits, float internetDataUsageUnitsAmount, float billMonth, float stateGST,
			float centralGST, float totalBillAmount, float localSmsAmount, float stdSmsAmount, float localCallAmount,
			float stdCallAmount) {
		super();
		this.billID = billID;
		this.noOfLocalSms = noOfLocalSms;
		this.noOfStdSms = noOfStdSms;
		this.noOfStdCalls = noOfStdCalls;
		this.noOfLocalCalls = noOfLocalCalls;
		this.internetDataUsageUnits = internetDataUsageUnits;
		this.internetDataUsageUnitsAmount = internetDataUsageUnitsAmount;
		this.billMonth = billMonth;
		this.stateGST = stateGST;
		this.centralGST = centralGST;
		this.totalBillAmount = totalBillAmount;
		this.localSmsAmount = localSmsAmount;
		this.stdSmsAmount = stdSmsAmount;
		this.localCallAmount = localCallAmount;
		this.stdCallAmount = stdCallAmount;
	}
	public int getBillID() {
		return billID;
	}
	public void setBillID(int billID) {
		this.billID = billID;
	}
	public int getNoOfLocalSms() {
		return noOfLocalSms;
	}
	public void setNoOfLocalSms(int noOfLocalSms) {
		this.noOfLocalSms = noOfLocalSms;
	}
	public int getNoOfStdSms() {
		return noOfStdSms;
	}
	public void setNoOfStdSms(int noOfStdSms) {
		this.noOfStdSms = noOfStdSms;
	}
	public int getNoOfStdCalls() {
		return noOfStdCalls;
	}
	public void setNoOfStdCalls(int noOfStdCalls) {
		this.noOfStdCalls = noOfStdCalls;
	}
	public int getNoOfLocalCalls() {
		return noOfLocalCalls;
	}
	public void setNoOfLocalCalls(int noOfLocalCalls) {
		this.noOfLocalCalls = noOfLocalCalls;
	}
	public float getInternetDataUsageUnits() {
		return internetDataUsageUnits;
	}
	public void setInternetDataUsageUnits(float internetDataUsageUnits) {
		this.internetDataUsageUnits = internetDataUsageUnits;
	}
	public float getInternetDataUsageUnitsAmount() {
		return internetDataUsageUnitsAmount;
	}
	public void setInternetDataUsageUnitsAmount(float internetDataUsageUnitsAmount) {
		this.internetDataUsageUnitsAmount = internetDataUsageUnitsAmount;
	}
	public float getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(float billMonth) {
		this.billMonth = billMonth;
	}
	public float getStateGST() {
		return stateGST;
	}
	public void setStateGST(float stateGST) {
		this.stateGST = stateGST;
	}
	public float getCentralGST() {
		return centralGST;
	}
	public void setCentralGST(float centralGST) {
		this.centralGST = centralGST;
	}
	public float getTotalBillAmount() {
		return totalBillAmount;
	}
	public void setTotalBillAmount(float totalBillAmount) {
		this.totalBillAmount = totalBillAmount;
	}
	public float getLocalSmsAmount() {
		return localSmsAmount;
	}
	public void setLocalSmsAmount(float localSmsAmount) {
		this.localSmsAmount = localSmsAmount;
	}
	public float getStdSmsAmount() {
		return stdSmsAmount;
	}
	public void setStdSmsAmount(float stdSmsAmount) {
		this.stdSmsAmount = stdSmsAmount;
	}
	public float getLocalCallAmount() {
		return localCallAmount;
	}
	public void setLocalCallAmount(float localCallAmount) {
		this.localCallAmount = localCallAmount;
	}
	public float getStdCallAmount() {
		return stdCallAmount;
	}
	public void setStdCallAmount(float stdCallAmount) {
		this.stdCallAmount = stdCallAmount;
	}
}
