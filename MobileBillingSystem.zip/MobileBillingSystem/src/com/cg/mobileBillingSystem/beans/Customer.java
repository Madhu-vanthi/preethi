package com.cg.mobileBillingSystem.beans;

public class Customer {

	private int customerID,adharNum,dateOfBirth;
	private String firstName,lastname,emailID,pancardNum;
	private PostPaidAccount[] postPaidAccounts=new PostPaidAccount[3];
	public Customer() {
	}
	public Customer(int customerID, int adharNum, int dateOfBirth, String firstName, String lastname, String emailID,
			String pancardNum) {
		super();
		this.customerID = customerID;
		this.adharNum = adharNum;
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.lastname = lastname;
		this.emailID = emailID;
		this.pancardNum = pancardNum;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public int getAdharNum() {
		return adharNum;
	}
	public void setAdharNum(int adharNum) {
		this.adharNum = adharNum;
	}
	public int getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(int dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getPancardNum() {
		return pancardNum;
	}
	public void setPancardNum(String pancardNum) {
		this.pancardNum = pancardNum;
	}
}
