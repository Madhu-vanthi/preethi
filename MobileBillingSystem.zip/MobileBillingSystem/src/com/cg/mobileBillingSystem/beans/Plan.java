package com.cg.mobileBillingSystem.beans;

public class Plan {

	private int planID,freeLocalCalls,freeStdCals,freeLocalSms,freeStdSms;
	private float monthlyRental,freeInternetUsageUnits,localCallRate,stdcallRate,
	                          localSmsRate,stdSmsRate,InternetDataUsageRate,planCircle;
	private String planName;
	public Plan(int planID, int freeLocalCalls, int freeStdCals, int freeLocalSms, int freeStdSms, float monthlyRental,
			float freeInternetUsageUnits, float localCallRate, float stdcallRate, float localSmsRate, float stdSmsRate,
			float internetDataUsageRate, float planCircle, String planName) {
		super();
		this.planID = planID;
		this.freeLocalCalls = freeLocalCalls;
		this.freeStdCals = freeStdCals;
		this.freeLocalSms = freeLocalSms;
		this.freeStdSms = freeStdSms;
		this.monthlyRental = monthlyRental;
		this.freeInternetUsageUnits = freeInternetUsageUnits;
		this.localCallRate = localCallRate;
		this.stdcallRate = stdcallRate;
		this.localSmsRate = localSmsRate;
		this.stdSmsRate = stdSmsRate;
		InternetDataUsageRate = internetDataUsageRate;
		this.planCircle = planCircle;
		this.planName = planName;
	}
	public int getPlanID() {
		return planID;
	}
	public void setPlanID(int planID) {
		this.planID = planID;
	}
	public int getFreeLocalCalls() {
		return freeLocalCalls;
	}
	public void setFreeLocalCalls(int freeLocalCalls) {
		this.freeLocalCalls = freeLocalCalls;
	}
	public int getFreeStdCals() {
		return freeStdCals;
	}
	public void setFreeStdCals(int freeStdCals) {
		this.freeStdCals = freeStdCals;
	}
	public int getFreeLocalSms() {
		return freeLocalSms;
	}
	public void setFreeLocalSms(int freeLocalSms) {
		this.freeLocalSms = freeLocalSms;
	}
	public int getFreeStdSms() {
		return freeStdSms;
	}
	public void setFreeStdSms(int freeStdSms) {
		this.freeStdSms = freeStdSms;
	}
	public float getMonthlyRental() {
		return monthlyRental;
	}
	public void setMonthlyRental(float monthlyRental) {
		this.monthlyRental = monthlyRental;
	}
	public float getFreeInternetUsageUnits() {
		return freeInternetUsageUnits;
	}
	public void setFreeInternetUsageUnits(float freeInternetUsageUnits) {
		this.freeInternetUsageUnits = freeInternetUsageUnits;
	}
	public float getLocalCallRate() {
		return localCallRate;
	}
	public void setLocalCallRate(float localCallRate) {
		this.localCallRate = localCallRate;
	}
	public float getStdcallRate() {
		return stdcallRate;
	}
	public void setStdcallRate(float stdcallRate) {
		this.stdcallRate = stdcallRate;
	}
	public float getLocalSmsRate() {
		return localSmsRate;
	}
	public void setLocalSmsRate(float localSmsRate) {
		this.localSmsRate = localSmsRate;
	}
	public float getStdSmsRate() {
		return stdSmsRate;
	}
	public void setStdSmsRate(float stdSmsRate) {
		this.stdSmsRate = stdSmsRate;
	}
	public float getInternetDataUsageRate() {
		return InternetDataUsageRate;
	}
	public void setInternetDataUsageRate(float internetDataUsageRate) {
		InternetDataUsageRate = internetDataUsageRate;
	}
	public float getPlanCircle() {
		return planCircle;
	}
	public void setPlanCircle(float planCircle) {
		this.planCircle = planCircle;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
}
