package com.cg.mobileBillingSystem.client;

public class MobileBillingSystem {

	public static void main(String[] args) {
		
	}

}
