package com.cg.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory {

	WebDriver driver;

	public LoginPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name="userName")
	@CacheLookup
	WebElement uname;
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement password;
	
	@FindBy(how=How.CLASS_NAME, using="btn")
	@CacheLookup
	WebElement btn;
	
	public WebElement getUname() {
		return uname;
	}

	public void setUname(String un) {
		uname.sendKeys(un);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String pwd) {
		password.sendKeys(pwd);
	}

	public WebElement getBtn() {
		return btn;
	}

	public void setBtn() {
		btn.click();
	}	
}
