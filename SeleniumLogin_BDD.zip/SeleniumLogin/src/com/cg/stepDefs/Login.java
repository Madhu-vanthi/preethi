package com.cg.stepDefs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.Before;

public class Login {
	class LoginStepDefs{

	WebDriver driver;
	
	@Before
	public void OpenBrowserWindow() {
		
		String driverPath = "D:\\\\Lesson 5-HTML Pages\\\\chromedriver_win32\\\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///D:/Lesson%205-HTML%20Pages/login.html");
	}
	}

}
