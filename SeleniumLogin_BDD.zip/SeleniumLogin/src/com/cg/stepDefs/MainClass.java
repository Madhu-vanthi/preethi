package com.cg.stepDefs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainClass {

	 static WebDriver driver=null;
     static String alertMessage=null;
     
     public static void main(String[] args) {
    	 String driverPath = "D:\\\\Lesson 5-HTML Pages\\\\chromedriver_win32\\\\";
 		 System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
 		 driver = new ChromeDriver();
         driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
         driver.get("file:///D:/Lesson%205-HTML%20Pages/Hotel/login.html");

         String title=driver.getTitle();
         System.out.println("The page title is :" + title);
         
         
         /******* For blank user Name *******/
         driver.findElement(By.name("userName")).sendKeys("");
         driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();  
         /******* For blank password *******/
         driver.findElement(By.name("userPwd")).sendKeys("");
         driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();  
 
         
         /******* For valid User Name *******/
         driver.findElement(By.name("userName")).sendKeys("capgemini");
         

         /******* For valid password *******/
         driver.findElement(By.name("userPwd")).sendKeys("capg1234");
         
         /*****for correct username and password***/
         driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
         driver.navigate().to("file:///D:/Lesson%205-HTML%20Pages/success.html");
         driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
         
 }
     public static void callAlert()
     {
         String alertMessage=driver.switchTo().alert().getText();
         System.out.println(alertMessage);       
         driver.switchTo().alert().accept();
     }

}
