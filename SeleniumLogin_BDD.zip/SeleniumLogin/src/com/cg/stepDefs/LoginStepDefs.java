package com.cg.stepDefs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.cg.bean.LoginPageFactory;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefs {
	
	private WebDriver driver;
	private LoginPageFactory log = new LoginPageFactory(driver);
	
	@Before
	public void OpenBrowserWindow() {
		
		String driverPath = "D:\\\\Lesson 5-HTML Pages\\\\chromedriver_win32\\\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		driver = new ChromeDriver();
		//log = new LoginPageFactory(driver);
		//driver.get("file:///D:/Lesson%205-HTML%20Pages/login.html");
	}

	@Given("^User is on the homepage$")
	public void user_is_on_the_homepage() throws Throwable {
	    
		log = new LoginPageFactory(driver);
		driver.get("file:///D:/Lesson%205-HTML%20Pages/Hotel/login.html");
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}

	@Then("^Check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {	    
		
		String title = driver.getTitle();
		if(title.contentEquals("Login Page")) System.out.println("Title Matched : " + title);
		else System.out.println("Title Mismatch");
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}

	@When("^User enters all valid credentials$")
	public void user_enters_all_valid_credentials() throws Throwable {
	    
		log.setUname("capgemini");	Thread.sleep(500);
		log.setPassword("capg1234");	Thread.sleep(500);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		log.setBtn();	
	}

	@Then("^Move on to success page$")
	public void move_on_to_success_page() throws Throwable {
	    
		driver.navigate().to("file:///D:/Lesson%205-HTML%20Pages/Hotel/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^User enters Valid username and Invalid password$")
	public void user_enters_Valid_username_and_Invalid_password() throws Throwable {
	    
		log.setUname("capgemini");	Thread.sleep(500);
		log.setPassword("dghb");	Thread.sleep(500);	
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}

	@When("^Clicks the button$")
	public void clicks_the_button() throws Throwable {
	   
		log.setBtn();
	}

	@Then("^Print alert message$")
	public void print_alert_message() throws Throwable {
	  
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(500);
		System.out.println(alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User enters Invalid username$")
	public void user_enters_Invalid_username() throws Throwable {
	   
		log.setUname("dszchb");	Thread.sleep(500);
		log.setPassword("capg1234");	Thread.sleep(500);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}

	@When("^User leaves the username empty$")
	public void user_leaves_the_username_empty() throws Throwable {
	   
		log.setUname("");
	}
	
	@Then("^Display error message for username$")
	public void display_error_message() throws Throwable {
	 
		String Error = driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
		System.out.println(Error);
	}


	@When("^User leaves the password empty$")
	public void user_leaves_the_password_empty() throws Throwable {
	   
		log.setUname("capgemini");
		log.setPassword("");
	}
	
	@Then("^Display error message for password$")
	public void display_error_message_for_password() throws Throwable {
	    
		String Error = driver.findElement(By.xpath(".//*[@id='pwdErrMsg']")).getText();
		System.out.println(Error);
	}
	
	@After
	public void CloseBrowserWindow() {
		
		driver.close();
	}


}
